﻿namespace WJ_HustleForProfit_003.Shared
{
    public static class EventIds
    {
        public const int AppStart = 1001;
        public const int AppStop = 1002;
        public const int UserLogin = 1003;
        public const int UserLogout = 1004;
        // Add more event IDs as needed
    }
}
