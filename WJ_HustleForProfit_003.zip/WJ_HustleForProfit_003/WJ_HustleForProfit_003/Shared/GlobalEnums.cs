﻿namespace WJ_HustleForProfit_003.Shared
{
    public class GlobalEnums
    {
        public enum TransactionTypeID
        {
            NewRegistration = 1,
            eBookTransaction = 2,
            SocialMediaTransaction = 3
        }
    }
}
