﻿namespace WJ_HustleForProfit_003.Forms
{
    partial class frmHustleListing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.statusBar1 = new Wisej.Web.StatusBar();
            this.pnlMain = new Wisej.Web.Panel();
            this.pnlHustle = new Wisej.Web.Panel();
            this.splitContainer1 = new Wisej.Web.SplitContainer();
            this.splitContainer2 = new Wisej.Web.SplitContainer();
            this.pictureBoxHustleBillboard = new Wisej.Web.PictureBox();
            this.upload1 = new Wisej.Web.Upload();
            this.txtHustleVideoURL = new Wisej.Web.TextBox();
            this.splitContainer3 = new Wisej.Web.SplitContainer();
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.comboBox5 = new Wisej.Web.ComboBox();
            this.label10 = new Wisej.Web.Label();
            this.comboBox4 = new Wisej.Web.ComboBox();
            this.label9 = new Wisej.Web.Label();
            this.comboBox3 = new Wisej.Web.ComboBox();
            this.label8 = new Wisej.Web.Label();
            this.comboBox2 = new Wisej.Web.ComboBox();
            this.label7 = new Wisej.Web.Label();
            this.comboBox1 = new Wisej.Web.ComboBox();
            this.label6 = new Wisej.Web.Label();
            this.textBox3 = new Wisej.Web.TextBox();
            this.label5 = new Wisej.Web.Label();
            this.textBox1 = new Wisej.Web.TextBox();
            this.label4 = new Wisej.Web.Label();
            this.textBox2 = new Wisej.Web.TextBox();
            this.label3 = new Wisej.Web.Label();
            this.label1 = new Wisej.Web.Label();
            this.upload2 = new Wisej.Web.Upload();
            this.pictureBox1 = new Wisej.Web.PictureBox();
            this.label2 = new Wisej.Web.Label();
            this.pnlHustleBottom = new Wisej.Web.Panel();
            this.toolBarHustle = new Wisej.Web.ToolBar();
            this.pnlTop = new Wisej.Web.Panel();
            this.splitButtonWizard = new Wisej.Web.SplitButton();
            this.splitButtonMenuItemNewHustle = new Wisej.Web.MenuItem();
            this.splitButtonMenuItemHustleWizard = new Wisej.Web.MenuItem();
            this.pnlMain.SuspendLayout();
            this.pnlHustle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHustleBillboard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusBar1
            // 
            this.statusBar1.Location = new System.Drawing.Point(0, 763);
            this.statusBar1.Name = "statusBar1";
            this.statusBar1.Size = new System.Drawing.Size(1138, 22);
            this.statusBar1.TabIndex = 0;
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.pnlHustle);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = Wisej.Web.DockStyle.Fill;
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.ShowCloseButton = false;
            this.pnlMain.Size = new System.Drawing.Size(1138, 763);
            this.pnlMain.TabIndex = 1;
            // 
            // pnlHustle
            // 
            this.pnlHustle.Controls.Add(this.splitContainer1);
            this.pnlHustle.Controls.Add(this.toolBarHustle);
            this.pnlHustle.Dock = Wisej.Web.DockStyle.Fill;
            this.pnlHustle.Location = new System.Drawing.Point(0, 112);
            this.pnlHustle.Name = "pnlHustle";
            this.pnlHustle.ShowCloseButton = false;
            this.pnlHustle.Size = new System.Drawing.Size(1138, 651);
            this.pnlHustle.TabIndex = 1;
            this.pnlHustle.Visible = false;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = Wisej.Web.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 32);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer3);
            this.splitContainer1.Size = new System.Drawing.Size(1138, 619);
            this.splitContainer1.SplitterDistance = 375;
            this.splitContainer1.TabIndex = 1;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = Wisej.Web.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = Wisej.Web.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.pictureBoxHustleBillboard);
            this.splitContainer2.Panel1.Controls.Add(this.upload1);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.txtHustleVideoURL);
            this.splitContainer2.Size = new System.Drawing.Size(375, 619);
            this.splitContainer2.SplitterDistance = 275;
            this.splitContainer2.TabIndex = 0;
            // 
            // pictureBoxHustleBillboard
            // 
            this.pictureBoxHustleBillboard.Dock = Wisej.Web.DockStyle.Fill;
            this.pictureBoxHustleBillboard.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxHustleBillboard.Name = "pictureBoxHustleBillboard";
            this.pictureBoxHustleBillboard.Size = new System.Drawing.Size(373, 243);
            // 
            // upload1
            // 
            this.upload1.Dock = Wisej.Web.DockStyle.Bottom;
            this.upload1.Location = new System.Drawing.Point(0, 243);
            this.upload1.Name = "upload1";
            this.upload1.Size = new System.Drawing.Size(373, 30);
            this.upload1.TabIndex = 0;
            this.upload1.Text = "Upload Hustle Billboard";
            // 
            // txtHustleVideoURL
            // 
            this.txtHustleVideoURL.Dock = Wisej.Web.DockStyle.Bottom;
            this.txtHustleVideoURL.LabelText = "Hustle Video URL:";
            this.txtHustleVideoURL.Location = new System.Drawing.Point(0, 280);
            this.txtHustleVideoURL.Name = "txtHustleVideoURL";
            this.txtHustleVideoURL.Size = new System.Drawing.Size(373, 53);
            this.txtHustleVideoURL.TabIndex = 0;
            this.txtHustleVideoURL.Text = "https://www.youtube.com/watch?v=iz-k9UfmYHM";
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = Wisej.Web.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.tableLayoutPanel1);
            this.splitContainer3.Panel1.Controls.Add(this.pnlHustleBottom);
            this.splitContainer3.Size = new System.Drawing.Size(754, 619);
            this.splitContainer3.SplitterDistance = 516;
            this.splitContainer3.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.comboBox5, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.label10, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.comboBox4, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.label9, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.comboBox3, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.comboBox2, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.comboBox1, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.label6, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBox3, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBox1, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBox2, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.upload2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.Padding = new Wisej.Web.Padding(5);
            this.tableLayoutPanel1.RowCount = 12;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(514, 517);
            this.tableLayoutPanel1.TabIndex = 3;
            // 
            // comboBox5
            // 
            this.comboBox5.AutoSize = false;
            this.comboBox5.Dock = Wisej.Web.DockStyle.Fill;
            this.comboBox5.Location = new System.Drawing.Point(128, 403);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(378, 29);
            this.comboBox5.TabIndex = 23;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = Wisej.Web.DockStyle.Fill;
            this.label10.Location = new System.Drawing.Point(8, 403);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(114, 29);
            this.label10.TabIndex = 22;
            this.label10.Text = "Flipbook";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // comboBox4
            // 
            this.comboBox4.AutoSize = false;
            this.comboBox4.Dock = Wisej.Web.DockStyle.Fill;
            this.comboBox4.Location = new System.Drawing.Point(128, 368);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(378, 29);
            this.comboBox4.TabIndex = 21;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = Wisej.Web.DockStyle.Fill;
            this.label9.Location = new System.Drawing.Point(8, 368);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(114, 29);
            this.label9.TabIndex = 20;
            this.label9.Text = "Audiobook";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // comboBox3
            // 
            this.comboBox3.AutoSize = false;
            this.comboBox3.Dock = Wisej.Web.DockStyle.Fill;
            this.comboBox3.Location = new System.Drawing.Point(128, 333);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(378, 29);
            this.comboBox3.TabIndex = 19;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = Wisej.Web.DockStyle.Fill;
            this.label8.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label8.Location = new System.Drawing.Point(8, 333);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(114, 29);
            this.label8.TabIndex = 18;
            this.label8.Text = "Marketing Plan:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // comboBox2
            // 
            this.comboBox2.AutoSize = false;
            this.comboBox2.Dock = Wisej.Web.DockStyle.Fill;
            this.comboBox2.Location = new System.Drawing.Point(128, 298);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(378, 29);
            this.comboBox2.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = Wisej.Web.DockStyle.Fill;
            this.label7.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label7.Location = new System.Drawing.Point(8, 298);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(114, 29);
            this.label7.TabIndex = 16;
            this.label7.Text = "Business Plan:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // comboBox1
            // 
            this.comboBox1.AutoSize = false;
            this.comboBox1.Dock = Wisej.Web.DockStyle.Fill;
            this.comboBox1.Location = new System.Drawing.Point(128, 263);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(378, 29);
            this.comboBox1.TabIndex = 15;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = Wisej.Web.DockStyle.Fill;
            this.label6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label6.Location = new System.Drawing.Point(8, 263);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 29);
            this.label6.TabIndex = 14;
            this.label6.Text = "eBook:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox3
            // 
            this.textBox3.AutoSize = false;
            this.textBox3.Dock = Wisej.Web.DockStyle.Fill;
            this.textBox3.Location = new System.Drawing.Point(128, 203);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(378, 54);
            this.textBox3.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = Wisej.Web.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(8, 203);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 54);
            this.label5.TabIndex = 11;
            this.label5.Text = "Description:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox1
            // 
            this.textBox1.AutoSize = false;
            this.textBox1.Dock = Wisej.Web.DockStyle.Fill;
            this.textBox1.Location = new System.Drawing.Point(128, 173);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(378, 24);
            this.textBox1.TabIndex = 10;
            this.textBox1.Watermark = "Hustle Title (make it original and SEO sensitive)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = Wisej.Web.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(8, 173);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 24);
            this.label4.TabIndex = 9;
            this.label4.Text = "Tag Line:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox2
            // 
            this.textBox2.AutoSize = false;
            this.textBox2.Dock = Wisej.Web.DockStyle.Fill;
            this.textBox2.Location = new System.Drawing.Point(128, 143);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(378, 24);
            this.textBox2.TabIndex = 8;
            this.textBox2.Watermark = "Hustle Title (make it original and SEO sensitive)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = Wisej.Web.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(8, 143);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 24);
            this.label3.TabIndex = 7;
            this.label3.Text = "Hustle Listing Title:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = Wisej.Web.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(8, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 94);
            this.label1.TabIndex = 6;
            this.label1.Text = "Hustle Listing Logo (W:500xH100)";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // upload2
            // 
            this.upload2.ButtonPosition = System.Drawing.ContentAlignment.MiddleLeft;
            this.upload2.Dock = Wisej.Web.DockStyle.Left;
            this.upload2.Location = new System.Drawing.Point(128, 108);
            this.upload2.Name = "upload2";
            this.upload2.Size = new System.Drawing.Size(327, 29);
            this.upload2.TabIndex = 5;
            this.upload2.Text = "upload2";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(128, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(327, 94);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = Wisej.Web.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(8, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 29);
            this.label2.TabIndex = 2;
            this.label2.Text = "Upload Logo:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pnlHustleBottom
            // 
            this.pnlHustleBottom.Dock = Wisej.Web.DockStyle.Bottom;
            this.pnlHustleBottom.Location = new System.Drawing.Point(0, 517);
            this.pnlHustleBottom.Name = "pnlHustleBottom";
            this.pnlHustleBottom.Size = new System.Drawing.Size(514, 100);
            this.pnlHustleBottom.TabIndex = 2;
            // 
            // toolBarHustle
            // 
            this.toolBarHustle.Location = new System.Drawing.Point(0, 0);
            this.toolBarHustle.Name = "toolBarHustle";
            this.toolBarHustle.Size = new System.Drawing.Size(1138, 32);
            this.toolBarHustle.TabIndex = 0;
            this.toolBarHustle.TabStop = false;
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.pnlTop.Controls.Add(this.splitButtonWizard);
            this.pnlTop.Dock = Wisej.Web.DockStyle.Top;
            this.pnlTop.HeaderSize = 25;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Padding = new Wisej.Web.Padding(5);
            this.pnlTop.ShowCloseButton = false;
            this.pnlTop.Size = new System.Drawing.Size(1138, 112);
            this.pnlTop.TabIndex = 0;
            // 
            // splitButtonWizard
            // 
            this.splitButtonWizard.Dock = Wisej.Web.DockStyle.Left;
            this.splitButtonWizard.Location = new System.Drawing.Point(5, 5);
            this.splitButtonWizard.MenuItems.AddRange(new Wisej.Web.MenuItem[] {
            this.splitButtonMenuItemNewHustle,
            this.splitButtonMenuItemHustleWizard});
            this.splitButtonWizard.Name = "splitButtonWizard";
            this.splitButtonWizard.Size = new System.Drawing.Size(100, 100);
            this.splitButtonWizard.TabIndex = 1;
            this.splitButtonWizard.Text = "New Hustle Listing";
            this.splitButtonWizard.Click += new System.EventHandler(this.splitButtonWizard_Click);
            // 
            // splitButtonMenuItemNewHustle
            // 
            this.splitButtonMenuItemNewHustle.Index = 0;
            this.splitButtonMenuItemNewHustle.Name = "splitButtonMenuItemNewHustle";
            this.splitButtonMenuItemNewHustle.Text = "Create New Hustle Listing";
            // 
            // splitButtonMenuItemHustleWizard
            // 
            this.splitButtonMenuItemHustleWizard.Enabled = false;
            this.splitButtonMenuItemHustleWizard.Index = 1;
            this.splitButtonMenuItemHustleWizard.Name = "splitButtonMenuItemHustleWizard";
            this.splitButtonMenuItemHustleWizard.Text = "New Hustle Listing Wizard";
            // 
            // frmHustleListing
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 19F);
            this.AutoScaleMode = Wisej.Web.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1138, 785);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.statusBar1);
            this.Name = "frmHustleListing";
            this.Text = "Hustle Listing";
            this.Load += new System.EventHandler(this.frmHustles_Load);
            this.pnlMain.ResumeLayout(false);
            this.pnlHustle.ResumeLayout(false);
            this.pnlHustle.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHustleBillboard)).EndInit();
            this.splitContainer3.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.StatusBar statusBar1;
        private Wisej.Web.Panel pnlMain;
        private Wisej.Web.Panel pnlTop;
        private Wisej.Web.Panel pnlHustle;
        private Wisej.Web.ToolBar toolBarHustle;
        private Wisej.Web.SplitContainer splitContainer1;
        private Wisej.Web.SplitContainer splitContainer2;
        private Wisej.Web.Upload upload1;
        private Wisej.Web.TextBox txtHustleVideoURL;
        private Wisej.Web.PictureBox pictureBoxHustleBillboard;
        private Wisej.Web.SplitContainer splitContainer3;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.TextBox textBox3;
        private Wisej.Web.Label label5;
        private Wisej.Web.TextBox textBox1;
        private Wisej.Web.Label label4;
        private Wisej.Web.TextBox textBox2;
        private Wisej.Web.Label label3;
        private Wisej.Web.Label label1;
        private Wisej.Web.Upload upload2;
        private Wisej.Web.PictureBox pictureBox1;
        private Wisej.Web.Label label2;
        private Wisej.Web.Panel pnlHustleBottom;
        private Wisej.Web.SplitButton splitButtonWizard;
        private Wisej.Web.MenuItem splitButtonMenuItemNewHustle;
        private Wisej.Web.MenuItem splitButtonMenuItemHustleWizard;
        private Wisej.Web.Label label6;
        private Wisej.Web.ComboBox comboBox1;
        private Wisej.Web.Label label8;
        private Wisej.Web.ComboBox comboBox2;
        private Wisej.Web.Label label7;
        private Wisej.Web.Label label10;
        private Wisej.Web.ComboBox comboBox4;
        private Wisej.Web.Label label9;
        private Wisej.Web.ComboBox comboBox3;
        private Wisej.Web.ComboBox comboBox5;
    }
}