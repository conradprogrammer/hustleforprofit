﻿namespace WJ_HustleForProfit_003.Forms
{
    partial class frmEBookCreation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Wisej.Web.ComponentTool componentTool7 = new Wisej.Web.ComponentTool();
            Wisej.Web.ComponentTool componentTool8 = new Wisej.Web.ComponentTool();
            Wisej.Web.ComponentTool componentTool9 = new Wisej.Web.ComponentTool();
            Wisej.Web.ComponentTool componentTool10 = new Wisej.Web.ComponentTool();
            Wisej.Web.ComponentTool componentTool11 = new Wisej.Web.ComponentTool();
            Wisej.Web.ComponentTool componentTool12 = new Wisej.Web.ComponentTool();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEBookCreation));
            this.pnlTop = new Wisej.Web.Panel();
            this.flowLayoutPanelEBook = new Wisej.Web.FlowLayoutPanel();
            this.line1 = new Wisej.Web.Line();
            this.splitButtonEBook = new Wisej.Web.SplitButton();
            this.splitButtonMenuItemNewHustle = new Wisej.Web.MenuItem();
            this.splitButtonMenuItemHustleWizard = new Wisej.Web.MenuItem();
            this.toolBarEBook = new Wisej.Web.ToolBar();
            this.statusBar1 = new Wisej.Web.StatusBar();
            this.pnlSideEBookCover = new Wisej.Web.Panel();
            this.tableLayoutPanel4 = new Wisej.Web.TableLayoutPanel();
            this.textBox2 = new Wisej.Web.TextBox();
            this.txtEBookID = new Wisej.Web.TextBox();
            this.txtEBookCoverSaveAs = new Wisej.Web.TextBox();
            this.txtEBookCoverPublisher = new Wisej.Web.TextBox();
            this.cboEBookCoverBookFormat = new Wisej.Web.ComboBox();
            this.txtEBookCoverSerial = new Wisej.Web.TextBox();
            this.txtEBookCoverVideoURL = new Wisej.Web.TextBox();
            this.tableLayoutPanel2 = new Wisej.Web.TableLayoutPanel();
            this.chkSaveSideEBookCover = new Wisej.Web.CheckBox();
            this.btnEBookCoverSaveAndNextStep = new Wisej.Web.Button();
            this.txtEBookCoverTitle = new Wisej.Web.TextBox();
            this.txtEBookCoverByline = new Wisej.Web.TextBox();
            this.txtEBookCoverShortDescription = new Wisej.Web.TextBox();
            this.txtEBookCoverAuthor = new Wisej.Web.TextBox();
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.groupBox2 = new Wisej.Web.GroupBox();
            this.label11 = new Wisej.Web.Label();
            this.uploadEBookCover = new Wisej.Web.Upload();
            this.pictureBoxEBookCoverImage = new Wisej.Web.PictureBox();
            this.pnlSideEBookWriter = new Wisej.Web.Panel();
            this.splitContainerEBookWriter1 = new Wisej.Web.SplitContainer();
            this.tableLayoutPanel3 = new Wisej.Web.TableLayoutPanel();
            this.groupBox1 = new Wisej.Web.GroupBox();
            this.radioEBookWriterExtraLong = new Wisej.Web.RadioButton();
            this.radioEBookWriterDefaultLength = new Wisej.Web.RadioButton();
            this.txtEBookWriterAIPrompt = new Wisej.Web.TextBox();
            this.txtEBookWriterBookSummary = new Wisej.Web.TextBox();
            this.numericUpDownChapters = new Wisej.Web.NumericUpDown();
            this.btnGenerateChapterTitles = new Wisej.Web.Button();
            this.splitContainerEBookWriter2 = new Wisej.Web.SplitContainer();
            this.tableLayoutPanelEBookWriterChapters = new Wisej.Web.TableLayoutPanel();
            this.chkSaveSideEBookWriter = new Wisej.Web.CheckBox();
            this.btnGenBookNextStepPDF = new Wisej.Web.Button();
            this.chkChapter6 = new Wisej.Web.CheckBox();
            this.chkChapter5 = new Wisej.Web.CheckBox();
            this.chkChapter4 = new Wisej.Web.CheckBox();
            this.chkChapter3 = new Wisej.Web.CheckBox();
            this.chkChapter2 = new Wisej.Web.CheckBox();
            this.txtBookChapter04 = new Wisej.Web.TextBox();
            this.chkChapter1 = new Wisej.Web.CheckBox();
            this.txtBookChapter06 = new Wisej.Web.TextBox();
            this.txtBookChapter05 = new Wisej.Web.TextBox();
            this.txtBookChapter03 = new Wisej.Web.TextBox();
            this.txtBookChapter02 = new Wisej.Web.TextBox();
            this.txtBookChapter01 = new Wisej.Web.TextBox();
            this.lblEBookStatus = new Wisej.Web.Label();
            this.btnGenBookLayout = new Wisej.Web.Button();
            this.tabControlEBookChapters = new Wisej.Web.TabControl();
            this.tabPageChapter1 = new Wisej.Web.TabPage();
            this.tinyEditorChapter1 = new Wisej.Web.Ext.TinyEditor.TinyEditor();
            this.lblBookChapter01 = new Wisej.Web.Label();
            this.btnGenBookChapter01 = new Wisej.Web.Button();
            this.tabPageChapter2 = new Wisej.Web.TabPage();
            this.tinyEditorChapter2 = new Wisej.Web.Ext.TinyEditor.TinyEditor();
            this.lblBookChapter02 = new Wisej.Web.Label();
            this.btnGenBookChapter02 = new Wisej.Web.Button();
            this.tabPageChapter3 = new Wisej.Web.TabPage();
            this.tinyEditorChapter3 = new Wisej.Web.Ext.TinyEditor.TinyEditor();
            this.lblBookChapter03 = new Wisej.Web.Label();
            this.btnGenBookChapter03 = new Wisej.Web.Button();
            this.tabPageChapter4 = new Wisej.Web.TabPage();
            this.tinyEditorChapter4 = new Wisej.Web.Ext.TinyEditor.TinyEditor();
            this.lblBookChapter04 = new Wisej.Web.Label();
            this.btnGenBookChapter04 = new Wisej.Web.Button();
            this.tabPageChapter5 = new Wisej.Web.TabPage();
            this.tinyEditorChapter5 = new Wisej.Web.Ext.TinyEditor.TinyEditor();
            this.lblBookChapter05 = new Wisej.Web.Label();
            this.btnGenBookChapter05 = new Wisej.Web.Button();
            this.tabPageChapter6 = new Wisej.Web.TabPage();
            this.tinyEditorChapter6 = new Wisej.Web.Ext.TinyEditor.TinyEditor();
            this.lblBookChapter06 = new Wisej.Web.Label();
            this.btnGenBookChapter06 = new Wisej.Web.Button();
            this.pnlSideEBookPDFViewer = new Wisej.Web.Panel();
            this.splitContainer1 = new Wisej.Web.SplitContainer();
            this.btnGenBookFinalPDF = new Wisej.Web.Button();
            this.splitContainer2 = new Wisej.Web.SplitContainer();
            this.pdfViewer1 = new Wisej.Web.PdfViewer();
            this.btnNextStepFlipbook = new Wisej.Web.Button();
            this.pnlSideEBookFlipbook = new Wisej.Web.Panel();
            this.splitContainerFlipbook = new Wisej.Web.SplitContainer();
            this.webBrowser1 = new Wisej.Web.WebBrowser();
            this.pnlTop.SuspendLayout();
            this.pnlSideEBookCover.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEBookCoverImage)).BeginInit();
            this.pnlSideEBookWriter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerEBookWriter1)).BeginInit();
            this.splitContainerEBookWriter1.Panel1.SuspendLayout();
            this.splitContainerEBookWriter1.Panel2.SuspendLayout();
            this.splitContainerEBookWriter1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownChapters)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerEBookWriter2)).BeginInit();
            this.splitContainerEBookWriter2.Panel1.SuspendLayout();
            this.splitContainerEBookWriter2.Panel2.SuspendLayout();
            this.splitContainerEBookWriter2.SuspendLayout();
            this.tableLayoutPanelEBookWriterChapters.SuspendLayout();
            this.tabControlEBookChapters.SuspendLayout();
            this.tabPageChapter1.SuspendLayout();
            this.tabPageChapter2.SuspendLayout();
            this.tabPageChapter3.SuspendLayout();
            this.tabPageChapter4.SuspendLayout();
            this.tabPageChapter5.SuspendLayout();
            this.tabPageChapter6.SuspendLayout();
            this.pnlSideEBookPDFViewer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.pnlSideEBookFlipbook.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerFlipbook)).BeginInit();
            this.splitContainerFlipbook.Panel1.SuspendLayout();
            this.splitContainerFlipbook.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.pnlTop.Controls.Add(this.flowLayoutPanelEBook);
            this.pnlTop.Controls.Add(this.line1);
            this.pnlTop.Controls.Add(this.splitButtonEBook);
            this.pnlTop.Dock = Wisej.Web.DockStyle.Top;
            this.pnlTop.HeaderSize = 25;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Padding = new Wisej.Web.Padding(5);
            this.pnlTop.ShowCloseButton = false;
            this.pnlTop.Size = new System.Drawing.Size(1409, 112);
            this.pnlTop.TabIndex = 2;
            // 
            // flowLayoutPanelEBook
            // 
            this.flowLayoutPanelEBook.AutoScroll = true;
            this.flowLayoutPanelEBook.Dock = Wisej.Web.DockStyle.Fill;
            this.flowLayoutPanelEBook.Location = new System.Drawing.Point(132, 5);
            this.flowLayoutPanelEBook.Name = "flowLayoutPanelEBook";
            this.flowLayoutPanelEBook.Padding = new Wisej.Web.Padding(0, 0, 10, 0);
            this.flowLayoutPanelEBook.ScrollBars = Wisej.Web.ScrollBars.Horizontal;
            this.flowLayoutPanelEBook.ShowCloseButton = false;
            this.flowLayoutPanelEBook.Size = new System.Drawing.Size(1270, 100);
            this.flowLayoutPanelEBook.TabIndex = 3;
            // 
            // line1
            // 
            this.line1.Dock = Wisej.Web.DockStyle.Left;
            this.line1.Location = new System.Drawing.Point(105, 5);
            this.line1.Name = "line1";
            this.line1.Orientation = Wisej.Web.Orientation.Vertical;
            this.line1.Size = new System.Drawing.Size(27, 100);
            // 
            // splitButtonEBook
            // 
            this.splitButtonEBook.Dock = Wisej.Web.DockStyle.Left;
            this.splitButtonEBook.Location = new System.Drawing.Point(5, 5);
            this.splitButtonEBook.MenuItems.AddRange(new Wisej.Web.MenuItem[] {
            this.splitButtonMenuItemNewHustle,
            this.splitButtonMenuItemHustleWizard});
            this.splitButtonEBook.Name = "splitButtonEBook";
            this.splitButtonEBook.Size = new System.Drawing.Size(100, 100);
            this.splitButtonEBook.TabIndex = 1;
            this.splitButtonEBook.Text = "New eBook Creation";
            this.splitButtonEBook.Click += new System.EventHandler(this.splitButtonEBook_Click);
            // 
            // splitButtonMenuItemNewHustle
            // 
            this.splitButtonMenuItemNewHustle.Index = 0;
            this.splitButtonMenuItemNewHustle.Name = "splitButtonMenuItemNewHustle";
            this.splitButtonMenuItemNewHustle.Text = "Create New Hustle";
            // 
            // splitButtonMenuItemHustleWizard
            // 
            this.splitButtonMenuItemHustleWizard.Index = 1;
            this.splitButtonMenuItemHustleWizard.Name = "splitButtonMenuItemHustleWizard";
            this.splitButtonMenuItemHustleWizard.Text = "New Hustle Wizard";
            // 
            // toolBarEBook
            // 
            this.toolBarEBook.Location = new System.Drawing.Point(0, 112);
            this.toolBarEBook.Name = "toolBarEBook";
            this.toolBarEBook.Size = new System.Drawing.Size(1409, 32);
            this.toolBarEBook.TabIndex = 3;
            this.toolBarEBook.TabStop = false;
            // 
            // statusBar1
            // 
            this.statusBar1.Location = new System.Drawing.Point(0, 785);
            this.statusBar1.Name = "statusBar1";
            this.statusBar1.Size = new System.Drawing.Size(1409, 22);
            this.statusBar1.TabIndex = 4;
            // 
            // pnlSideEBookCover
            // 
            this.pnlSideEBookCover.CollapseSide = Wisej.Web.HeaderPosition.Left;
            this.pnlSideEBookCover.Controls.Add(this.tableLayoutPanel4);
            this.pnlSideEBookCover.Controls.Add(this.tableLayoutPanel2);
            this.pnlSideEBookCover.Controls.Add(this.tableLayoutPanel1);
            this.pnlSideEBookCover.Dock = Wisej.Web.DockStyle.Left;
            this.pnlSideEBookCover.Location = new System.Drawing.Point(0, 144);
            this.pnlSideEBookCover.Name = "pnlSideEBookCover";
            this.pnlSideEBookCover.ResizableEdges = Wisej.Web.AnchorStyles.Right;
            this.pnlSideEBookCover.ShowHeader = true;
            this.pnlSideEBookCover.Size = new System.Drawing.Size(1137, 641);
            this.pnlSideEBookCover.TabIndex = 5;
            this.pnlSideEBookCover.Text = "eBook Cover";
            this.pnlSideEBookCover.Visible = false;
            this.pnlSideEBookCover.PanelExpanded += new System.EventHandler(this.pnlSideEBookCover_PanelExpanded);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.textBox2, 0, 5);
            this.tableLayoutPanel4.Controls.Add(this.txtEBookID, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.txtEBookCoverSaveAs, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.txtEBookCoverPublisher, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.cboEBookCoverBookFormat, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.txtEBookCoverSerial, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.txtEBookCoverVideoURL, 0, 6);
            this.tableLayoutPanel4.Dock = Wisej.Web.DockStyle.Left;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(696, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.Padding = new Wisej.Web.Padding(10);
            this.tableLayoutPanel4.ResizableEdges = Wisej.Web.AnchorStyles.Right;
            this.tableLayoutPanel4.RowCount = 9;
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 100F));
            this.tableLayoutPanel4.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 50F));
            this.tableLayoutPanel4.ShowCloseButton = false;
            this.tableLayoutPanel4.Size = new System.Drawing.Size(360, 613);
            this.tableLayoutPanel4.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.AutoSize = false;
            this.textBox2.Dock = Wisej.Web.DockStyle.Fill;
            this.textBox2.LabelText = "HustleListing QR Code:";
            this.textBox2.Location = new System.Drawing.Point(13, 313);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(334, 54);
            this.textBox2.TabIndex = 8;
            componentTool7.ImageSource = "Icons\\ado-ai-16.png";
            this.textBox2.Tools.AddRange(new Wisej.Web.ComponentTool[] {
            componentTool7});
            this.textBox2.Watermark = "Serial Number or ISBN (QR Code)";
            // 
            // txtEBookID
            // 
            this.txtEBookID.Dock = Wisej.Web.DockStyle.Bottom;
            this.txtEBookID.Enabled = false;
            this.txtEBookID.Label.Font = new System.Drawing.Font("Arial", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtEBookID.Label.Padding = new Wisej.Web.Padding(0, 0, 0, 1);
            this.txtEBookID.LabelText = "Book ID (auto assigned)";
            this.txtEBookID.Location = new System.Drawing.Point(13, 81);
            this.txtEBookID.Name = "txtEBookID";
            this.txtEBookID.ReadOnly = true;
            this.txtEBookID.Size = new System.Drawing.Size(334, 46);
            this.txtEBookID.TabIndex = 7;
            this.txtEBookID.Text = "0";
            // 
            // txtEBookCoverSaveAs
            // 
            this.txtEBookCoverSaveAs.AutoSize = false;
            this.txtEBookCoverSaveAs.Dock = Wisej.Web.DockStyle.Fill;
            this.txtEBookCoverSaveAs.Label.Font = new System.Drawing.Font("Arial", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.txtEBookCoverSaveAs.Label.Padding = new Wisej.Web.Padding(0, 0, 0, 1);
            this.txtEBookCoverSaveAs.Label.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.txtEBookCoverSaveAs.LabelText = "Save As... (max 15 char.):";
            this.txtEBookCoverSaveAs.Location = new System.Drawing.Point(13, 13);
            this.txtEBookCoverSaveAs.MaxLength = 15;
            this.txtEBookCoverSaveAs.Name = "txtEBookCoverSaveAs";
            this.txtEBookCoverSaveAs.Size = new System.Drawing.Size(334, 54);
            this.txtEBookCoverSaveAs.TabIndex = 3;
            this.txtEBookCoverSaveAs.Text = "Book 001";
            componentTool8.ImageSource = "icon-saveas";
            this.txtEBookCoverSaveAs.Tools.AddRange(new Wisej.Web.ComponentTool[] {
            componentTool8});
            this.txtEBookCoverSaveAs.Watermark = "Short reference";
            this.txtEBookCoverSaveAs.ToolClick += new Wisej.Web.ToolClickEventHandler(this.txtEBookCoverSaveAs_ToolClick);
            // 
            // txtEBookCoverPublisher
            // 
            this.txtEBookCoverPublisher.AutoSize = false;
            this.txtEBookCoverPublisher.Dock = Wisej.Web.DockStyle.Fill;
            this.txtEBookCoverPublisher.LabelText = "Publisher:";
            this.txtEBookCoverPublisher.Location = new System.Drawing.Point(13, 133);
            this.txtEBookCoverPublisher.Name = "txtEBookCoverPublisher";
            this.txtEBookCoverPublisher.Size = new System.Drawing.Size(334, 54);
            this.txtEBookCoverPublisher.TabIndex = 4;
            this.txtEBookCoverPublisher.Text = "American Association of Small Business Leaders";
            this.txtEBookCoverPublisher.Watermark = "Publisher";
            // 
            // cboEBookCoverBookFormat
            // 
            this.cboEBookCoverBookFormat.Dock = Wisej.Web.DockStyle.Fill;
            this.cboEBookCoverBookFormat.Items.AddRange(new object[] {
            "PDF"});
            this.cboEBookCoverBookFormat.LabelText = "Book Format:";
            this.cboEBookCoverBookFormat.Location = new System.Drawing.Point(13, 193);
            this.cboEBookCoverBookFormat.Name = "cboEBookCoverBookFormat";
            this.cboEBookCoverBookFormat.Size = new System.Drawing.Size(334, 54);
            this.cboEBookCoverBookFormat.TabIndex = 3;
            this.cboEBookCoverBookFormat.Text = "PDF";
            // 
            // txtEBookCoverSerial
            // 
            this.txtEBookCoverSerial.AutoSize = false;
            this.txtEBookCoverSerial.Dock = Wisej.Web.DockStyle.Fill;
            this.txtEBookCoverSerial.LabelText = "Serial/ISBN or QR Code:";
            this.txtEBookCoverSerial.Location = new System.Drawing.Point(13, 253);
            this.txtEBookCoverSerial.Name = "txtEBookCoverSerial";
            this.txtEBookCoverSerial.Size = new System.Drawing.Size(334, 54);
            this.txtEBookCoverSerial.TabIndex = 5;
            componentTool9.ImageSource = "Icons\\ado-ai-16.png";
            this.txtEBookCoverSerial.Tools.AddRange(new Wisej.Web.ComponentTool[] {
            componentTool9});
            this.txtEBookCoverSerial.Watermark = "Serial Number or ISBN (QR Code)";
            // 
            // txtEBookCoverVideoURL
            // 
            this.txtEBookCoverVideoURL.AutoSize = false;
            this.txtEBookCoverVideoURL.Dock = Wisej.Web.DockStyle.Fill;
            this.txtEBookCoverVideoURL.LabelText = "Video URL (YouTube):";
            this.txtEBookCoverVideoURL.Location = new System.Drawing.Point(13, 373);
            this.txtEBookCoverVideoURL.Name = "txtEBookCoverVideoURL";
            this.txtEBookCoverVideoURL.Size = new System.Drawing.Size(334, 54);
            this.txtEBookCoverVideoURL.TabIndex = 6;
            this.txtEBookCoverVideoURL.Watermark = "Video URL (YouTube)";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.chkSaveSideEBookCover, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.btnEBookCoverSaveAndNextStep, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.txtEBookCoverTitle, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtEBookCoverByline, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.txtEBookCoverShortDescription, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.txtEBookCoverAuthor, 0, 1);
            this.tableLayoutPanel2.Dock = Wisej.Web.DockStyle.Left;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(336, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.Padding = new Wisej.Web.Padding(10);
            this.tableLayoutPanel2.ResizableEdges = Wisej.Web.AnchorStyles.Right;
            this.tableLayoutPanel2.RowCount = 7;
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 150F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 200F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.ShowCloseButton = false;
            this.tableLayoutPanel2.Size = new System.Drawing.Size(360, 613);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // chkSaveSideEBookCover
            // 
            this.chkSaveSideEBookCover.Dock = Wisej.Web.DockStyle.Fill;
            this.chkSaveSideEBookCover.Enabled = false;
            this.chkSaveSideEBookCover.Location = new System.Drawing.Point(13, 576);
            this.chkSaveSideEBookCover.Name = "chkSaveSideEBookCover";
            this.chkSaveSideEBookCover.Size = new System.Drawing.Size(334, 24);
            this.chkSaveSideEBookCover.TabIndex = 8;
            this.chkSaveSideEBookCover.Text = "Save eBook on Next Step";
            this.chkSaveSideEBookCover.ToolTipText = "Only available for non Trial Members, by checking this, your eBook will be saved " +
    "and you can retrieve it later.";
            // 
            // btnEBookCoverSaveAndNextStep
            // 
            this.btnEBookCoverSaveAndNextStep.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.btnEBookCoverSaveAndNextStep.Dock = Wisej.Web.DockStyle.Fill;
            this.btnEBookCoverSaveAndNextStep.Location = new System.Drawing.Point(13, 516);
            this.btnEBookCoverSaveAndNextStep.Name = "btnEBookCoverSaveAndNextStep";
            this.btnEBookCoverSaveAndNextStep.Size = new System.Drawing.Size(334, 54);
            this.btnEBookCoverSaveAndNextStep.TabIndex = 7;
            this.btnEBookCoverSaveAndNextStep.Text = "Next Step";
            this.btnEBookCoverSaveAndNextStep.Click += new System.EventHandler(this.btnEBookCoverSaveAndNextStep_Click);
            // 
            // txtEBookCoverTitle
            // 
            this.txtEBookCoverTitle.AutoSize = false;
            this.txtEBookCoverTitle.Dock = Wisej.Web.DockStyle.Fill;
            this.txtEBookCoverTitle.Label.Font = new System.Drawing.Font("Arial", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.txtEBookCoverTitle.Label.Padding = new Wisej.Web.Padding(0, 0, 0, 1);
            this.txtEBookCoverTitle.Label.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.txtEBookCoverTitle.LabelText = "eBook Title:";
            this.txtEBookCoverTitle.Location = new System.Drawing.Point(13, 13);
            this.txtEBookCoverTitle.Multiline = true;
            this.txtEBookCoverTitle.Name = "txtEBookCoverTitle";
            this.txtEBookCoverTitle.Size = new System.Drawing.Size(334, 54);
            this.txtEBookCoverTitle.TabIndex = 0;
            componentTool10.ImageSource = "Icons\\ado-ai-16.png";
            this.txtEBookCoverTitle.Tools.AddRange(new Wisej.Web.ComponentTool[] {
            componentTool10});
            this.txtEBookCoverTitle.Watermark = "eBook Book Title. Click the AI icon to have it generated for you.";
            this.txtEBookCoverTitle.ToolClick += new Wisej.Web.ToolClickEventHandler(this.txtEBookCoverTitle_ToolClick);
            // 
            // txtEBookCoverByline
            // 
            this.txtEBookCoverByline.AutoSize = false;
            this.txtEBookCoverByline.Dock = Wisej.Web.DockStyle.Fill;
            this.txtEBookCoverByline.Label.Padding = new Wisej.Web.Padding(0, 0, 0, 1);
            this.txtEBookCoverByline.LabelText = "Byline:";
            this.txtEBookCoverByline.Location = new System.Drawing.Point(13, 133);
            this.txtEBookCoverByline.Multiline = true;
            this.txtEBookCoverByline.Name = "txtEBookCoverByline";
            this.txtEBookCoverByline.Size = new System.Drawing.Size(334, 144);
            this.txtEBookCoverByline.TabIndex = 1;
            componentTool11.ImageSource = "Icons\\ado-ai-16.png";
            this.txtEBookCoverByline.Tools.AddRange(new Wisej.Web.ComponentTool[] {
            componentTool11});
            this.txtEBookCoverByline.Watermark = "Byline";
            this.txtEBookCoverByline.ToolClick += new Wisej.Web.ToolClickEventHandler(this.txtEBookCoverByline_ToolClick);
            // 
            // txtEBookCoverShortDescription
            // 
            this.txtEBookCoverShortDescription.AutoSize = false;
            this.txtEBookCoverShortDescription.Dock = Wisej.Web.DockStyle.Fill;
            this.txtEBookCoverShortDescription.Label.Font = new System.Drawing.Font("Arial", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.txtEBookCoverShortDescription.Label.Padding = new Wisej.Web.Padding(0, 0, 0, 1);
            this.txtEBookCoverShortDescription.LabelText = "Short Book Description:";
            this.txtEBookCoverShortDescription.Location = new System.Drawing.Point(13, 283);
            this.txtEBookCoverShortDescription.Multiline = true;
            this.txtEBookCoverShortDescription.Name = "txtEBookCoverShortDescription";
            this.txtEBookCoverShortDescription.Size = new System.Drawing.Size(334, 194);
            this.txtEBookCoverShortDescription.TabIndex = 2;
            componentTool12.ImageSource = "Icons\\ado-ai-16.png";
            this.txtEBookCoverShortDescription.Tools.AddRange(new Wisej.Web.ComponentTool[] {
            componentTool12});
            this.txtEBookCoverShortDescription.ToolClick += new Wisej.Web.ToolClickEventHandler(this.txtEBookCoverShortDescription_ToolClick);
            this.txtEBookCoverShortDescription.TextChanged += new System.EventHandler(this.txtEBookCoverShortDescription_TextChanged);
            // 
            // txtEBookCoverAuthor
            // 
            this.txtEBookCoverAuthor.AutoSize = false;
            this.txtEBookCoverAuthor.Label.Font = new System.Drawing.Font("Arial", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.txtEBookCoverAuthor.Label.Padding = new Wisej.Web.Padding(0, 0, 0, 1);
            this.txtEBookCoverAuthor.LabelText = "Author:";
            this.txtEBookCoverAuthor.Location = new System.Drawing.Point(13, 73);
            this.txtEBookCoverAuthor.Name = "txtEBookCoverAuthor";
            this.txtEBookCoverAuthor.Size = new System.Drawing.Size(334, 54);
            this.txtEBookCoverAuthor.TabIndex = 2;
            this.txtEBookCoverAuthor.Watermark = "Author";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.groupBox2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBoxEBookCoverImage, 0, 0);
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Left;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.Padding = new Wisej.Web.Padding(10);
            this.tableLayoutPanel1.ResizableEdges = Wisej.Web.AnchorStyles.Right;
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 130F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(336, 613);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.uploadEBookCover);
            this.groupBox2.Dock = Wisej.Web.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(13, 476);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(310, 124);
            this.groupBox2.TabIndex = 34;
            this.groupBox2.Text = "Upload Book Cover: ";
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(6, 44);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(239, 38);
            this.label11.TabIndex = 33;
            this.label11.Text = "Only .JPG or .PNG. Best 720x1280 or 19:6 aspect ratio. 1MB MAX!";
            // 
            // uploadEBookCover
            // 
            this.uploadEBookCover.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.uploadEBookCover.Dock = Wisej.Web.DockStyle.Bottom;
            this.uploadEBookCover.Enabled = false;
            this.uploadEBookCover.Location = new System.Drawing.Point(3, 91);
            this.uploadEBookCover.Name = "uploadEBookCover";
            this.uploadEBookCover.Size = new System.Drawing.Size(304, 30);
            this.uploadEBookCover.TabIndex = 32;
            this.uploadEBookCover.Uploaded += new Wisej.Web.UploadedEventHandler(this.uploadEBookCover_Uploaded);
            // 
            // pictureBoxEBookCoverImage
            // 
            this.pictureBoxEBookCoverImage.Dock = Wisej.Web.DockStyle.Fill;
            this.pictureBoxEBookCoverImage.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxEBookCoverImage.Image")));
            this.pictureBoxEBookCoverImage.Location = new System.Drawing.Point(13, 13);
            this.pictureBoxEBookCoverImage.Name = "pictureBoxEBookCoverImage";
            this.pictureBoxEBookCoverImage.Size = new System.Drawing.Size(310, 457);
            this.pictureBoxEBookCoverImage.SizeMode = Wisej.Web.PictureBoxSizeMode.StretchImage;
            // 
            // pnlSideEBookWriter
            // 
            this.pnlSideEBookWriter.Collapsed = true;
            this.pnlSideEBookWriter.CollapseSide = Wisej.Web.HeaderPosition.Left;
            this.pnlSideEBookWriter.Controls.Add(this.splitContainerEBookWriter1);
            this.pnlSideEBookWriter.Dock = Wisej.Web.DockStyle.Left;
            this.pnlSideEBookWriter.Location = new System.Drawing.Point(1137, 144);
            this.pnlSideEBookWriter.Name = "pnlSideEBookWriter";
            this.pnlSideEBookWriter.ResizableEdges = Wisej.Web.AnchorStyles.Right;
            this.pnlSideEBookWriter.RestoreBounds = new System.Drawing.Rectangle(1137, 144, 1335, 641);
            this.pnlSideEBookWriter.ShowHeader = true;
            this.pnlSideEBookWriter.Size = new System.Drawing.Size(28, 641);
            this.pnlSideEBookWriter.TabIndex = 8;
            this.pnlSideEBookWriter.Text = "eBook Writer";
            this.pnlSideEBookWriter.Visible = false;
            this.pnlSideEBookWriter.PanelExpanded += new System.EventHandler(this.pnlSideEBookWriter_PanelExpanded);
            // 
            // splitContainerEBookWriter1
            // 
            this.splitContainerEBookWriter1.Dock = Wisej.Web.DockStyle.Fill;
            this.splitContainerEBookWriter1.Location = new System.Drawing.Point(0, 0);
            this.splitContainerEBookWriter1.Name = "splitContainerEBookWriter1";
            // 
            // splitContainerEBookWriter1.Panel1
            // 
            this.splitContainerEBookWriter1.Panel1.Controls.Add(this.tableLayoutPanel3);
            // 
            // splitContainerEBookWriter1.Panel2
            // 
            this.splitContainerEBookWriter1.Panel2.Controls.Add(this.splitContainerEBookWriter2);
            this.splitContainerEBookWriter1.Size = new System.Drawing.Size(1335, 641);
            this.splitContainerEBookWriter1.SplitterDistance = 356;
            this.splitContainerEBookWriter1.TabIndex = 0;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.groupBox1, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.txtEBookWriterAIPrompt, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.txtEBookWriterBookSummary, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.numericUpDownChapters, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.btnGenerateChapterTitles, 0, 6);
            this.tableLayoutPanel3.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.Padding = new Wisej.Web.Padding(10);
            this.tableLayoutPanel3.ResizableEdges = Wisej.Web.AnchorStyles.Right;
            this.tableLayoutPanel3.RowCount = 9;
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 140F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 140F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 70F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 70F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 30F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 30F));
            this.tableLayoutPanel3.ShowCloseButton = false;
            this.tableLayoutPanel3.Size = new System.Drawing.Size(354, 639);
            this.tableLayoutPanel3.TabIndex = 4;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioEBookWriterExtraLong);
            this.groupBox1.Controls.Add(this.radioEBookWriterDefaultLength);
            this.groupBox1.Dock = Wisej.Web.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(13, 293);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(328, 64);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.Text = "eBook Chapter Size: ";
            // 
            // radioEBookWriterExtraLong
            // 
            this.radioEBookWriterExtraLong.Location = new System.Drawing.Point(147, 25);
            this.radioEBookWriterExtraLong.Name = "radioEBookWriterExtraLong";
            this.radioEBookWriterExtraLong.Size = new System.Drawing.Size(151, 23);
            this.radioEBookWriterExtraLong.TabIndex = 1;
            this.radioEBookWriterExtraLong.Text = "Extra Long (VIP Only)";
            // 
            // radioEBookWriterDefaultLength
            // 
            this.radioEBookWriterDefaultLength.Checked = true;
            this.radioEBookWriterDefaultLength.Location = new System.Drawing.Point(15, 25);
            this.radioEBookWriterDefaultLength.Name = "radioEBookWriterDefaultLength";
            this.radioEBookWriterDefaultLength.Size = new System.Drawing.Size(115, 23);
            this.radioEBookWriterDefaultLength.TabIndex = 0;
            this.radioEBookWriterDefaultLength.TabStop = true;
            this.radioEBookWriterDefaultLength.Text = "Default Length";
            // 
            // txtEBookWriterAIPrompt
            // 
            this.txtEBookWriterAIPrompt.AutoSize = false;
            this.txtEBookWriterAIPrompt.Dock = Wisej.Web.DockStyle.Fill;
            this.txtEBookWriterAIPrompt.LabelText = "AI Prompt:";
            this.txtEBookWriterAIPrompt.Location = new System.Drawing.Point(13, 153);
            this.txtEBookWriterAIPrompt.Multiline = true;
            this.txtEBookWriterAIPrompt.Name = "txtEBookWriterAIPrompt";
            this.txtEBookWriterAIPrompt.Size = new System.Drawing.Size(328, 134);
            this.txtEBookWriterAIPrompt.TabIndex = 8;
            this.txtEBookWriterAIPrompt.Text = "this ebook is about how to sell digital art online";
            // 
            // txtEBookWriterBookSummary
            // 
            this.txtEBookWriterBookSummary.AutoSize = false;
            this.txtEBookWriterBookSummary.Dock = Wisej.Web.DockStyle.Fill;
            this.txtEBookWriterBookSummary.LabelText = "Book Summary:";
            this.txtEBookWriterBookSummary.Location = new System.Drawing.Point(13, 13);
            this.txtEBookWriterBookSummary.Multiline = true;
            this.txtEBookWriterBookSummary.Name = "txtEBookWriterBookSummary";
            this.txtEBookWriterBookSummary.Size = new System.Drawing.Size(328, 134);
            this.txtEBookWriterBookSummary.TabIndex = 9;
            this.txtEBookWriterBookSummary.Text = "this ebook is about how to sell digital art online";
            // 
            // numericUpDownChapters
            // 
            this.numericUpDownChapters.Dock = Wisej.Web.DockStyle.Fill;
            this.numericUpDownChapters.Enabled = false;
            this.numericUpDownChapters.LabelText = "eBook Chapters (1 for Trial otherwise max. 6):";
            this.numericUpDownChapters.Location = new System.Drawing.Point(13, 363);
            this.numericUpDownChapters.Maximum = new decimal(6);
            this.numericUpDownChapters.Minimum = new decimal(1);
            this.numericUpDownChapters.Name = "numericUpDownChapters";
            this.numericUpDownChapters.Size = new System.Drawing.Size(328, 64);
            this.numericUpDownChapters.TabIndex = 10;
            this.numericUpDownChapters.Value = new decimal(1);
            this.numericUpDownChapters.ValueChanged += new System.EventHandler(this.numericUpDownChapters_ValueChanged);
            // 
            // btnGenerateChapterTitles
            // 
            this.btnGenerateChapterTitles.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.btnGenerateChapterTitles.Dock = Wisej.Web.DockStyle.Fill;
            this.btnGenerateChapterTitles.Location = new System.Drawing.Point(13, 502);
            this.btnGenerateChapterTitles.Name = "btnGenerateChapterTitles";
            this.btnGenerateChapterTitles.Size = new System.Drawing.Size(328, 44);
            this.btnGenerateChapterTitles.TabIndex = 12;
            this.btnGenerateChapterTitles.Text = "Step 1: Generate Chapter Titles";
            this.btnGenerateChapterTitles.Click += new System.EventHandler(this.btnGenerateChapterTitles_Click);
            // 
            // splitContainerEBookWriter2
            // 
            this.splitContainerEBookWriter2.Dock = Wisej.Web.DockStyle.Fill;
            this.splitContainerEBookWriter2.Location = new System.Drawing.Point(0, 0);
            this.splitContainerEBookWriter2.Name = "splitContainerEBookWriter2";
            // 
            // splitContainerEBookWriter2.Panel1
            // 
            this.splitContainerEBookWriter2.Panel1.Controls.Add(this.tableLayoutPanelEBookWriterChapters);
            // 
            // splitContainerEBookWriter2.Panel2
            // 
            this.splitContainerEBookWriter2.Panel2.Controls.Add(this.tabControlEBookChapters);
            this.splitContainerEBookWriter2.Size = new System.Drawing.Size(970, 641);
            this.splitContainerEBookWriter2.SplitterDistance = 386;
            this.splitContainerEBookWriter2.TabIndex = 0;
            // 
            // tableLayoutPanelEBookWriterChapters
            // 
            this.tableLayoutPanelEBookWriterChapters.ColumnCount = 2;
            this.tableLayoutPanelEBookWriterChapters.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Absolute, 40F));
            this.tableLayoutPanelEBookWriterChapters.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanelEBookWriterChapters.Controls.Add(this.chkSaveSideEBookWriter, 1, 9);
            this.tableLayoutPanelEBookWriterChapters.Controls.Add(this.btnGenBookNextStepPDF, 1, 8);
            this.tableLayoutPanelEBookWriterChapters.Controls.Add(this.chkChapter6, 0, 5);
            this.tableLayoutPanelEBookWriterChapters.Controls.Add(this.chkChapter5, 0, 4);
            this.tableLayoutPanelEBookWriterChapters.Controls.Add(this.chkChapter4, 0, 3);
            this.tableLayoutPanelEBookWriterChapters.Controls.Add(this.chkChapter3, 0, 2);
            this.tableLayoutPanelEBookWriterChapters.Controls.Add(this.chkChapter2, 0, 1);
            this.tableLayoutPanelEBookWriterChapters.Controls.Add(this.txtBookChapter04, 1, 3);
            this.tableLayoutPanelEBookWriterChapters.Controls.Add(this.chkChapter1, 0, 0);
            this.tableLayoutPanelEBookWriterChapters.Controls.Add(this.txtBookChapter06, 1, 5);
            this.tableLayoutPanelEBookWriterChapters.Controls.Add(this.txtBookChapter05, 1, 4);
            this.tableLayoutPanelEBookWriterChapters.Controls.Add(this.txtBookChapter03, 1, 2);
            this.tableLayoutPanelEBookWriterChapters.Controls.Add(this.txtBookChapter02, 1, 1);
            this.tableLayoutPanelEBookWriterChapters.Controls.Add(this.txtBookChapter01, 1, 0);
            this.tableLayoutPanelEBookWriterChapters.Controls.Add(this.lblEBookStatus, 1, 6);
            this.tableLayoutPanelEBookWriterChapters.Controls.Add(this.btnGenBookLayout, 1, 7);
            this.tableLayoutPanelEBookWriterChapters.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanelEBookWriterChapters.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelEBookWriterChapters.Name = "tableLayoutPanelEBookWriterChapters";
            this.tableLayoutPanelEBookWriterChapters.Padding = new Wisej.Web.Padding(10);
            this.tableLayoutPanelEBookWriterChapters.RowCount = 10;
            this.tableLayoutPanelEBookWriterChapters.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 70F));
            this.tableLayoutPanelEBookWriterChapters.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 70F));
            this.tableLayoutPanelEBookWriterChapters.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 70F));
            this.tableLayoutPanelEBookWriterChapters.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 70F));
            this.tableLayoutPanelEBookWriterChapters.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 70F));
            this.tableLayoutPanelEBookWriterChapters.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 70F));
            this.tableLayoutPanelEBookWriterChapters.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 100F));
            this.tableLayoutPanelEBookWriterChapters.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 50F));
            this.tableLayoutPanelEBookWriterChapters.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 50F));
            this.tableLayoutPanelEBookWriterChapters.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 30F));
            this.tableLayoutPanelEBookWriterChapters.ShowCloseButton = false;
            this.tableLayoutPanelEBookWriterChapters.Size = new System.Drawing.Size(384, 639);
            this.tableLayoutPanelEBookWriterChapters.TabIndex = 3;
            // 
            // chkSaveSideEBookWriter
            // 
            this.chkSaveSideEBookWriter.Dock = Wisej.Web.DockStyle.Fill;
            this.chkSaveSideEBookWriter.Location = new System.Drawing.Point(53, 602);
            this.chkSaveSideEBookWriter.Name = "chkSaveSideEBookWriter";
            this.chkSaveSideEBookWriter.Size = new System.Drawing.Size(318, 24);
            this.chkSaveSideEBookWriter.TabIndex = 39;
            this.chkSaveSideEBookWriter.Text = "Save eBook Chapters on Next Step";
            this.chkSaveSideEBookWriter.Visible = false;
            // 
            // btnGenBookNextStepPDF
            // 
            this.btnGenBookNextStepPDF.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.btnGenBookNextStepPDF.Dock = Wisej.Web.DockStyle.Fill;
            this.btnGenBookNextStepPDF.Location = new System.Drawing.Point(53, 552);
            this.btnGenBookNextStepPDF.Name = "btnGenBookNextStepPDF";
            this.btnGenBookNextStepPDF.Size = new System.Drawing.Size(318, 44);
            this.btnGenBookNextStepPDF.TabIndex = 38;
            this.btnGenBookNextStepPDF.Text = "Go to next step: Create PDF";
            this.btnGenBookNextStepPDF.Visible = false;
            this.btnGenBookNextStepPDF.Click += new System.EventHandler(this.btnGenBookNextStepPDF_Click);
            // 
            // chkChapter6
            // 
            this.chkChapter6.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.chkChapter6.Dock = Wisej.Web.DockStyle.Bottom;
            this.chkChapter6.Enabled = false;
            this.chkChapter6.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.chkChapter6.Location = new System.Drawing.Point(13, 374);
            this.chkChapter6.Name = "chkChapter6";
            this.chkChapter6.Size = new System.Drawing.Size(34, 53);
            this.chkChapter6.TabIndex = 15;
            this.chkChapter6.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // chkChapter5
            // 
            this.chkChapter5.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.chkChapter5.Dock = Wisej.Web.DockStyle.Bottom;
            this.chkChapter5.Enabled = false;
            this.chkChapter5.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.chkChapter5.Location = new System.Drawing.Point(13, 304);
            this.chkChapter5.Name = "chkChapter5";
            this.chkChapter5.Size = new System.Drawing.Size(34, 53);
            this.chkChapter5.TabIndex = 14;
            this.chkChapter5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // chkChapter4
            // 
            this.chkChapter4.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.chkChapter4.Dock = Wisej.Web.DockStyle.Bottom;
            this.chkChapter4.Enabled = false;
            this.chkChapter4.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.chkChapter4.Location = new System.Drawing.Point(13, 234);
            this.chkChapter4.Name = "chkChapter4";
            this.chkChapter4.Size = new System.Drawing.Size(34, 53);
            this.chkChapter4.TabIndex = 13;
            this.chkChapter4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // chkChapter3
            // 
            this.chkChapter3.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.chkChapter3.Dock = Wisej.Web.DockStyle.Bottom;
            this.chkChapter3.Enabled = false;
            this.chkChapter3.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.chkChapter3.Location = new System.Drawing.Point(13, 164);
            this.chkChapter3.Name = "chkChapter3";
            this.chkChapter3.Size = new System.Drawing.Size(34, 53);
            this.chkChapter3.TabIndex = 12;
            this.chkChapter3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // chkChapter2
            // 
            this.chkChapter2.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.chkChapter2.Dock = Wisej.Web.DockStyle.Bottom;
            this.chkChapter2.Enabled = false;
            this.chkChapter2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.chkChapter2.Location = new System.Drawing.Point(13, 94);
            this.chkChapter2.Name = "chkChapter2";
            this.chkChapter2.Size = new System.Drawing.Size(34, 53);
            this.chkChapter2.TabIndex = 11;
            this.chkChapter2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // txtBookChapter04
            // 
            this.txtBookChapter04.AutoSize = false;
            this.txtBookChapter04.Dock = Wisej.Web.DockStyle.Fill;
            this.txtBookChapter04.Enabled = false;
            this.txtBookChapter04.LabelText = "Chapter 4:";
            this.txtBookChapter04.Location = new System.Drawing.Point(53, 223);
            this.txtBookChapter04.Multiline = true;
            this.txtBookChapter04.Name = "txtBookChapter04";
            this.txtBookChapter04.Size = new System.Drawing.Size(318, 64);
            this.txtBookChapter04.TabIndex = 10;
            // 
            // chkChapter1
            // 
            this.chkChapter1.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.chkChapter1.CheckState = Wisej.Web.CheckState.Checked;
            this.chkChapter1.Dock = Wisej.Web.DockStyle.Bottom;
            this.chkChapter1.Enabled = false;
            this.chkChapter1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.chkChapter1.Location = new System.Drawing.Point(13, 24);
            this.chkChapter1.Name = "chkChapter1";
            this.chkChapter1.Size = new System.Drawing.Size(34, 53);
            this.chkChapter1.TabIndex = 6;
            this.chkChapter1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // txtBookChapter06
            // 
            this.txtBookChapter06.AutoSize = false;
            this.txtBookChapter06.Dock = Wisej.Web.DockStyle.Fill;
            this.txtBookChapter06.Enabled = false;
            this.txtBookChapter06.LabelText = "Chapter 6:";
            this.txtBookChapter06.Location = new System.Drawing.Point(53, 363);
            this.txtBookChapter06.Multiline = true;
            this.txtBookChapter06.Name = "txtBookChapter06";
            this.txtBookChapter06.Size = new System.Drawing.Size(318, 64);
            this.txtBookChapter06.TabIndex = 5;
            // 
            // txtBookChapter05
            // 
            this.txtBookChapter05.AutoSize = false;
            this.txtBookChapter05.Dock = Wisej.Web.DockStyle.Fill;
            this.txtBookChapter05.Enabled = false;
            this.txtBookChapter05.LabelText = "Chapter 5:";
            this.txtBookChapter05.Location = new System.Drawing.Point(53, 293);
            this.txtBookChapter05.Multiline = true;
            this.txtBookChapter05.Name = "txtBookChapter05";
            this.txtBookChapter05.Size = new System.Drawing.Size(318, 64);
            this.txtBookChapter05.TabIndex = 4;
            // 
            // txtBookChapter03
            // 
            this.txtBookChapter03.AutoSize = false;
            this.txtBookChapter03.Dock = Wisej.Web.DockStyle.Fill;
            this.txtBookChapter03.Enabled = false;
            this.txtBookChapter03.LabelText = "Chapter 3:";
            this.txtBookChapter03.Location = new System.Drawing.Point(53, 153);
            this.txtBookChapter03.Multiline = true;
            this.txtBookChapter03.Name = "txtBookChapter03";
            this.txtBookChapter03.Size = new System.Drawing.Size(318, 64);
            this.txtBookChapter03.TabIndex = 2;
            // 
            // txtBookChapter02
            // 
            this.txtBookChapter02.AutoSize = false;
            this.txtBookChapter02.Dock = Wisej.Web.DockStyle.Fill;
            this.txtBookChapter02.Enabled = false;
            this.txtBookChapter02.LabelText = "Chapter 2:";
            this.txtBookChapter02.Location = new System.Drawing.Point(53, 83);
            this.txtBookChapter02.Multiline = true;
            this.txtBookChapter02.Name = "txtBookChapter02";
            this.txtBookChapter02.Size = new System.Drawing.Size(318, 64);
            this.txtBookChapter02.TabIndex = 1;
            // 
            // txtBookChapter01
            // 
            this.txtBookChapter01.AutoSize = false;
            this.txtBookChapter01.Dock = Wisej.Web.DockStyle.Fill;
            this.txtBookChapter01.LabelText = "Chapter 1:";
            this.txtBookChapter01.Location = new System.Drawing.Point(53, 13);
            this.txtBookChapter01.Multiline = true;
            this.txtBookChapter01.Name = "txtBookChapter01";
            this.txtBookChapter01.Size = new System.Drawing.Size(318, 64);
            this.txtBookChapter01.TabIndex = 0;
            // 
            // lblEBookStatus
            // 
            this.lblEBookStatus.Dock = Wisej.Web.DockStyle.Fill;
            this.lblEBookStatus.Location = new System.Drawing.Point(53, 433);
            this.lblEBookStatus.Name = "lblEBookStatus";
            this.lblEBookStatus.Size = new System.Drawing.Size(318, 63);
            this.lblEBookStatus.TabIndex = 37;
            this.lblEBookStatus.Text = "In order to generate eBooks a sufficient amount of credits is needed.";
            this.lblEBookStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnGenBookLayout
            // 
            this.btnGenBookLayout.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.btnGenBookLayout.Dock = Wisej.Web.DockStyle.Fill;
            this.btnGenBookLayout.Location = new System.Drawing.Point(53, 502);
            this.btnGenBookLayout.Name = "btnGenBookLayout";
            this.btnGenBookLayout.Size = new System.Drawing.Size(318, 44);
            this.btnGenBookLayout.TabIndex = 12;
            this.btnGenBookLayout.Text = "Step 2: Generate Book Draft using Free Points";
            this.btnGenBookLayout.Visible = false;
            this.btnGenBookLayout.Click += new System.EventHandler(this.btnGenBookLayout_Click);
            // 
            // tabControlEBookChapters
            // 
            this.tabControlEBookChapters.Controls.Add(this.tabPageChapter1);
            this.tabControlEBookChapters.Controls.Add(this.tabPageChapter2);
            this.tabControlEBookChapters.Controls.Add(this.tabPageChapter3);
            this.tabControlEBookChapters.Controls.Add(this.tabPageChapter4);
            this.tabControlEBookChapters.Controls.Add(this.tabPageChapter5);
            this.tabControlEBookChapters.Controls.Add(this.tabPageChapter6);
            this.tabControlEBookChapters.Dock = Wisej.Web.DockStyle.Left;
            this.tabControlEBookChapters.Location = new System.Drawing.Point(0, 0);
            this.tabControlEBookChapters.Name = "tabControlEBookChapters";
            this.tabControlEBookChapters.PageInsets = new Wisej.Web.Padding(11, 33, 11, 11);
            this.tabControlEBookChapters.Size = new System.Drawing.Size(556, 639);
            this.tabControlEBookChapters.TabIndex = 3;
            // 
            // tabPageChapter1
            // 
            this.tabPageChapter1.Controls.Add(this.tinyEditorChapter1);
            this.tabPageChapter1.Controls.Add(this.lblBookChapter01);
            this.tabPageChapter1.Controls.Add(this.btnGenBookChapter01);
            this.tabPageChapter1.Location = new System.Drawing.Point(11, 33);
            this.tabPageChapter1.Name = "tabPageChapter1";
            this.tabPageChapter1.Size = new System.Drawing.Size(534, 595);
            this.tabPageChapter1.Text = "Chapter 1";
            // 
            // tinyEditorChapter1
            // 
            this.tinyEditorChapter1.Dock = Wisej.Web.DockStyle.Fill;
            this.tinyEditorChapter1.Enabled = false;
            this.tinyEditorChapter1.Location = new System.Drawing.Point(0, 32);
            this.tinyEditorChapter1.Name = "tinyEditorChapter1";
            this.tinyEditorChapter1.Size = new System.Drawing.Size(534, 513);
            this.tinyEditorChapter1.TabIndex = 14;
            // 
            // lblBookChapter01
            // 
            this.lblBookChapter01.AllowHtml = true;
            this.lblBookChapter01.BackColor = System.Drawing.Color.AliceBlue;
            this.lblBookChapter01.Dock = Wisej.Web.DockStyle.Top;
            this.lblBookChapter01.Font = new System.Drawing.Font("default", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.lblBookChapter01.Location = new System.Drawing.Point(0, 0);
            this.lblBookChapter01.Name = "lblBookChapter01";
            this.lblBookChapter01.Padding = new Wisej.Web.Padding(6);
            this.lblBookChapter01.Size = new System.Drawing.Size(534, 32);
            this.lblBookChapter01.TabIndex = 13;
            this.lblBookChapter01.Text = "Book Chapter 01 (non-editable in Guest Mode)";
            // 
            // btnGenBookChapter01
            // 
            this.btnGenBookChapter01.AllowHtml = true;
            this.btnGenBookChapter01.AutoShowLoader = true;
            this.btnGenBookChapter01.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.btnGenBookChapter01.Dock = Wisej.Web.DockStyle.Bottom;
            this.btnGenBookChapter01.Location = new System.Drawing.Point(0, 545);
            this.btnGenBookChapter01.Name = "btnGenBookChapter01";
            this.btnGenBookChapter01.Size = new System.Drawing.Size(534, 50);
            this.btnGenBookChapter01.TabIndex = 12;
            this.btnGenBookChapter01.Text = "(Re) Generate Book Chapter 1";
            // 
            // tabPageChapter2
            // 
            this.tabPageChapter2.Controls.Add(this.tinyEditorChapter2);
            this.tabPageChapter2.Controls.Add(this.lblBookChapter02);
            this.tabPageChapter2.Controls.Add(this.btnGenBookChapter02);
            this.tabPageChapter2.Location = new System.Drawing.Point(11, 33);
            this.tabPageChapter2.Name = "tabPageChapter2";
            this.tabPageChapter2.Size = new System.Drawing.Size(534, 595);
            this.tabPageChapter2.Text = "Chapter 2";
            // 
            // tinyEditorChapter2
            // 
            this.tinyEditorChapter2.Dock = Wisej.Web.DockStyle.Fill;
            this.tinyEditorChapter2.Location = new System.Drawing.Point(0, 32);
            this.tinyEditorChapter2.Name = "tinyEditorChapter2";
            this.tinyEditorChapter2.Size = new System.Drawing.Size(534, 513);
            this.tinyEditorChapter2.TabIndex = 15;
            // 
            // lblBookChapter02
            // 
            this.lblBookChapter02.AllowHtml = true;
            this.lblBookChapter02.BackColor = System.Drawing.Color.AliceBlue;
            this.lblBookChapter02.Dock = Wisej.Web.DockStyle.Top;
            this.lblBookChapter02.Font = new System.Drawing.Font("default", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.lblBookChapter02.Location = new System.Drawing.Point(0, 0);
            this.lblBookChapter02.Name = "lblBookChapter02";
            this.lblBookChapter02.Padding = new Wisej.Web.Padding(6);
            this.lblBookChapter02.Size = new System.Drawing.Size(534, 32);
            this.lblBookChapter02.TabIndex = 13;
            this.lblBookChapter02.Text = "Book Chapter 02 (non-editable in Guest Mode)";
            // 
            // btnGenBookChapter02
            // 
            this.btnGenBookChapter02.AllowHtml = true;
            this.btnGenBookChapter02.AutoShowLoader = true;
            this.btnGenBookChapter02.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.btnGenBookChapter02.Dock = Wisej.Web.DockStyle.Bottom;
            this.btnGenBookChapter02.Location = new System.Drawing.Point(0, 545);
            this.btnGenBookChapter02.Name = "btnGenBookChapter02";
            this.btnGenBookChapter02.Size = new System.Drawing.Size(534, 50);
            this.btnGenBookChapter02.TabIndex = 12;
            this.btnGenBookChapter02.Text = "(Re) Generate Book Chapter 2";
            // 
            // tabPageChapter3
            // 
            this.tabPageChapter3.Controls.Add(this.tinyEditorChapter3);
            this.tabPageChapter3.Controls.Add(this.lblBookChapter03);
            this.tabPageChapter3.Controls.Add(this.btnGenBookChapter03);
            this.tabPageChapter3.Location = new System.Drawing.Point(11, 33);
            this.tabPageChapter3.Name = "tabPageChapter3";
            this.tabPageChapter3.Size = new System.Drawing.Size(534, 595);
            this.tabPageChapter3.Text = "Chapter 3";
            // 
            // tinyEditorChapter3
            // 
            this.tinyEditorChapter3.Dock = Wisej.Web.DockStyle.Fill;
            this.tinyEditorChapter3.Location = new System.Drawing.Point(0, 32);
            this.tinyEditorChapter3.Name = "tinyEditorChapter3";
            this.tinyEditorChapter3.Size = new System.Drawing.Size(534, 513);
            this.tinyEditorChapter3.TabIndex = 15;
            // 
            // lblBookChapter03
            // 
            this.lblBookChapter03.AllowHtml = true;
            this.lblBookChapter03.BackColor = System.Drawing.Color.AliceBlue;
            this.lblBookChapter03.Dock = Wisej.Web.DockStyle.Top;
            this.lblBookChapter03.Font = new System.Drawing.Font("default", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.lblBookChapter03.Location = new System.Drawing.Point(0, 0);
            this.lblBookChapter03.Name = "lblBookChapter03";
            this.lblBookChapter03.Padding = new Wisej.Web.Padding(6);
            this.lblBookChapter03.Size = new System.Drawing.Size(534, 32);
            this.lblBookChapter03.TabIndex = 13;
            this.lblBookChapter03.Text = "Book Chapter 03 (non-editable in Guest Mode)";
            // 
            // btnGenBookChapter03
            // 
            this.btnGenBookChapter03.AllowHtml = true;
            this.btnGenBookChapter03.AutoShowLoader = true;
            this.btnGenBookChapter03.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.btnGenBookChapter03.Dock = Wisej.Web.DockStyle.Bottom;
            this.btnGenBookChapter03.Location = new System.Drawing.Point(0, 545);
            this.btnGenBookChapter03.Name = "btnGenBookChapter03";
            this.btnGenBookChapter03.Size = new System.Drawing.Size(534, 50);
            this.btnGenBookChapter03.TabIndex = 12;
            this.btnGenBookChapter03.Text = "(Re) Generate Book Chapter 3";
            // 
            // tabPageChapter4
            // 
            this.tabPageChapter4.Controls.Add(this.tinyEditorChapter4);
            this.tabPageChapter4.Controls.Add(this.lblBookChapter04);
            this.tabPageChapter4.Controls.Add(this.btnGenBookChapter04);
            this.tabPageChapter4.Location = new System.Drawing.Point(11, 33);
            this.tabPageChapter4.Name = "tabPageChapter4";
            this.tabPageChapter4.Size = new System.Drawing.Size(534, 595);
            this.tabPageChapter4.Text = "Chapter 4";
            // 
            // tinyEditorChapter4
            // 
            this.tinyEditorChapter4.Dock = Wisej.Web.DockStyle.Fill;
            this.tinyEditorChapter4.Location = new System.Drawing.Point(0, 32);
            this.tinyEditorChapter4.Name = "tinyEditorChapter4";
            this.tinyEditorChapter4.Size = new System.Drawing.Size(534, 513);
            this.tinyEditorChapter4.TabIndex = 15;
            // 
            // lblBookChapter04
            // 
            this.lblBookChapter04.AllowHtml = true;
            this.lblBookChapter04.BackColor = System.Drawing.Color.AliceBlue;
            this.lblBookChapter04.Dock = Wisej.Web.DockStyle.Top;
            this.lblBookChapter04.Font = new System.Drawing.Font("default", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.lblBookChapter04.Location = new System.Drawing.Point(0, 0);
            this.lblBookChapter04.Name = "lblBookChapter04";
            this.lblBookChapter04.Padding = new Wisej.Web.Padding(6);
            this.lblBookChapter04.Size = new System.Drawing.Size(534, 32);
            this.lblBookChapter04.TabIndex = 13;
            this.lblBookChapter04.Text = "Book Chapter 04 (non-editable in Guest Mode)";
            // 
            // btnGenBookChapter04
            // 
            this.btnGenBookChapter04.AllowHtml = true;
            this.btnGenBookChapter04.AutoShowLoader = true;
            this.btnGenBookChapter04.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.btnGenBookChapter04.Dock = Wisej.Web.DockStyle.Bottom;
            this.btnGenBookChapter04.Location = new System.Drawing.Point(0, 545);
            this.btnGenBookChapter04.Name = "btnGenBookChapter04";
            this.btnGenBookChapter04.Size = new System.Drawing.Size(534, 50);
            this.btnGenBookChapter04.TabIndex = 12;
            this.btnGenBookChapter04.Text = "(Re) Generate Book Chapter 4";
            // 
            // tabPageChapter5
            // 
            this.tabPageChapter5.Controls.Add(this.tinyEditorChapter5);
            this.tabPageChapter5.Controls.Add(this.lblBookChapter05);
            this.tabPageChapter5.Controls.Add(this.btnGenBookChapter05);
            this.tabPageChapter5.Location = new System.Drawing.Point(11, 33);
            this.tabPageChapter5.Name = "tabPageChapter5";
            this.tabPageChapter5.Size = new System.Drawing.Size(534, 595);
            this.tabPageChapter5.Text = "Chapter 5";
            // 
            // tinyEditorChapter5
            // 
            this.tinyEditorChapter5.Dock = Wisej.Web.DockStyle.Fill;
            this.tinyEditorChapter5.Location = new System.Drawing.Point(0, 32);
            this.tinyEditorChapter5.Name = "tinyEditorChapter5";
            this.tinyEditorChapter5.Size = new System.Drawing.Size(534, 513);
            this.tinyEditorChapter5.TabIndex = 15;
            // 
            // lblBookChapter05
            // 
            this.lblBookChapter05.AllowHtml = true;
            this.lblBookChapter05.BackColor = System.Drawing.Color.AliceBlue;
            this.lblBookChapter05.Dock = Wisej.Web.DockStyle.Top;
            this.lblBookChapter05.Font = new System.Drawing.Font("default", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.lblBookChapter05.Location = new System.Drawing.Point(0, 0);
            this.lblBookChapter05.Name = "lblBookChapter05";
            this.lblBookChapter05.Padding = new Wisej.Web.Padding(6);
            this.lblBookChapter05.Size = new System.Drawing.Size(534, 32);
            this.lblBookChapter05.TabIndex = 12;
            this.lblBookChapter05.Text = "Book Chapter 05 (non-editable in Guest Mode)";
            // 
            // btnGenBookChapter05
            // 
            this.btnGenBookChapter05.AllowHtml = true;
            this.btnGenBookChapter05.AutoShowLoader = true;
            this.btnGenBookChapter05.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.btnGenBookChapter05.Dock = Wisej.Web.DockStyle.Bottom;
            this.btnGenBookChapter05.Location = new System.Drawing.Point(0, 545);
            this.btnGenBookChapter05.Name = "btnGenBookChapter05";
            this.btnGenBookChapter05.Size = new System.Drawing.Size(534, 50);
            this.btnGenBookChapter05.TabIndex = 11;
            this.btnGenBookChapter05.Text = "(Re) Generate Book Chapter 5";
            // 
            // tabPageChapter6
            // 
            this.tabPageChapter6.Controls.Add(this.tinyEditorChapter6);
            this.tabPageChapter6.Controls.Add(this.lblBookChapter06);
            this.tabPageChapter6.Controls.Add(this.btnGenBookChapter06);
            this.tabPageChapter6.Location = new System.Drawing.Point(11, 33);
            this.tabPageChapter6.Name = "tabPageChapter6";
            this.tabPageChapter6.Size = new System.Drawing.Size(534, 595);
            this.tabPageChapter6.Text = "Chapter 6";
            // 
            // tinyEditorChapter6
            // 
            this.tinyEditorChapter6.Dock = Wisej.Web.DockStyle.Fill;
            this.tinyEditorChapter6.Location = new System.Drawing.Point(0, 32);
            this.tinyEditorChapter6.Name = "tinyEditorChapter6";
            this.tinyEditorChapter6.Size = new System.Drawing.Size(534, 513);
            this.tinyEditorChapter6.TabIndex = 15;
            // 
            // lblBookChapter06
            // 
            this.lblBookChapter06.AllowHtml = true;
            this.lblBookChapter06.BackColor = System.Drawing.Color.AliceBlue;
            this.lblBookChapter06.Dock = Wisej.Web.DockStyle.Top;
            this.lblBookChapter06.Font = new System.Drawing.Font("default", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.lblBookChapter06.Location = new System.Drawing.Point(0, 0);
            this.lblBookChapter06.Name = "lblBookChapter06";
            this.lblBookChapter06.Padding = new Wisej.Web.Padding(6);
            this.lblBookChapter06.Size = new System.Drawing.Size(534, 32);
            this.lblBookChapter06.TabIndex = 11;
            this.lblBookChapter06.Text = "Book Chapter 06 (non-editable in Guest Mode)";
            // 
            // btnGenBookChapter06
            // 
            this.btnGenBookChapter06.AllowHtml = true;
            this.btnGenBookChapter06.AutoShowLoader = true;
            this.btnGenBookChapter06.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.btnGenBookChapter06.Dock = Wisej.Web.DockStyle.Bottom;
            this.btnGenBookChapter06.Location = new System.Drawing.Point(0, 545);
            this.btnGenBookChapter06.Name = "btnGenBookChapter06";
            this.btnGenBookChapter06.Size = new System.Drawing.Size(534, 50);
            this.btnGenBookChapter06.TabIndex = 10;
            this.btnGenBookChapter06.Text = "(Re) Generate Book Chapter 6";
            // 
            // pnlSideEBookPDFViewer
            // 
            this.pnlSideEBookPDFViewer.Collapsed = true;
            this.pnlSideEBookPDFViewer.CollapseSide = Wisej.Web.HeaderPosition.Left;
            this.pnlSideEBookPDFViewer.Controls.Add(this.splitContainer1);
            this.pnlSideEBookPDFViewer.Dock = Wisej.Web.DockStyle.Left;
            this.pnlSideEBookPDFViewer.Location = new System.Drawing.Point(1165, 144);
            this.pnlSideEBookPDFViewer.Name = "pnlSideEBookPDFViewer";
            this.pnlSideEBookPDFViewer.ResizableEdges = Wisej.Web.AnchorStyles.Right;
            this.pnlSideEBookPDFViewer.RestoreBounds = new System.Drawing.Rectangle(1165, 144, 1199, 641);
            this.pnlSideEBookPDFViewer.ShowHeader = true;
            this.pnlSideEBookPDFViewer.Size = new System.Drawing.Size(28, 641);
            this.pnlSideEBookPDFViewer.TabIndex = 9;
            this.pnlSideEBookPDFViewer.Text = "PDF Viewer";
            this.pnlSideEBookPDFViewer.Visible = false;
            this.pnlSideEBookPDFViewer.PanelExpanded += new System.EventHandler(this.pnlSideEBookPDFViewer_PanelExpanded);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = Wisej.Web.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.btnGenBookFinalPDF);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1199, 641);
            this.splitContainer1.SplitterDistance = 278;
            this.splitContainer1.TabIndex = 0;
            // 
            // btnGenBookFinalPDF
            // 
            this.btnGenBookFinalPDF.Dock = Wisej.Web.DockStyle.Bottom;
            this.btnGenBookFinalPDF.Location = new System.Drawing.Point(0, 595);
            this.btnGenBookFinalPDF.Name = "btnGenBookFinalPDF";
            this.btnGenBookFinalPDF.Size = new System.Drawing.Size(276, 44);
            this.btnGenBookFinalPDF.TabIndex = 7;
            this.btnGenBookFinalPDF.Text = "Generate Final PDF Book using Paid Credits";
            this.btnGenBookFinalPDF.Click += new System.EventHandler(this.btnGenBookFinalPDF_Click);
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = Wisej.Web.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.pdfViewer1);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.btnNextStepFlipbook);
            this.splitContainer2.Size = new System.Drawing.Size(912, 641);
            this.splitContainer2.SplitterDistance = 588;
            this.splitContainer2.TabIndex = 9;
            // 
            // pdfViewer1
            // 
            this.pdfViewer1.Dock = Wisej.Web.DockStyle.Fill;
            this.pdfViewer1.Location = new System.Drawing.Point(0, 0);
            this.pdfViewer1.Name = "pdfViewer1";
            this.pdfViewer1.Size = new System.Drawing.Size(586, 639);
            this.pdfViewer1.TabIndex = 10;
            // 
            // btnNextStepFlipbook
            // 
            this.btnNextStepFlipbook.Dock = Wisej.Web.DockStyle.Bottom;
            this.btnNextStepFlipbook.Location = new System.Drawing.Point(0, 595);
            this.btnNextStepFlipbook.Name = "btnNextStepFlipbook";
            this.btnNextStepFlipbook.Size = new System.Drawing.Size(313, 44);
            this.btnNextStepFlipbook.TabIndex = 10;
            this.btnNextStepFlipbook.Text = "Create a Flipbook for this project?";
            this.btnNextStepFlipbook.Visible = false;
            this.btnNextStepFlipbook.Click += new System.EventHandler(this.btnNextStepFlipbook_Click);
            // 
            // pnlSideEBookFlipbook
            // 
            this.pnlSideEBookFlipbook.Collapsed = true;
            this.pnlSideEBookFlipbook.CollapseSide = Wisej.Web.HeaderPosition.Left;
            this.pnlSideEBookFlipbook.Controls.Add(this.splitContainerFlipbook);
            this.pnlSideEBookFlipbook.Dock = Wisej.Web.DockStyle.Left;
            this.pnlSideEBookFlipbook.Location = new System.Drawing.Point(1193, 144);
            this.pnlSideEBookFlipbook.Name = "pnlSideEBookFlipbook";
            this.pnlSideEBookFlipbook.ResizableEdges = Wisej.Web.AnchorStyles.Right;
            this.pnlSideEBookFlipbook.RestoreBounds = new System.Drawing.Rectangle(1193, 144, 1172, 641);
            this.pnlSideEBookFlipbook.ShowHeader = true;
            this.pnlSideEBookFlipbook.Size = new System.Drawing.Size(28, 641);
            this.pnlSideEBookFlipbook.TabIndex = 10;
            this.pnlSideEBookFlipbook.Text = "eBook Flipbook";
            this.pnlSideEBookFlipbook.Visible = false;
            this.pnlSideEBookFlipbook.PanelExpanded += new System.EventHandler(this.pnlSideEBookFlipbook_PanelExpanded);
            // 
            // splitContainerFlipbook
            // 
            this.splitContainerFlipbook.Dock = Wisej.Web.DockStyle.Fill;
            this.splitContainerFlipbook.Location = new System.Drawing.Point(0, 0);
            this.splitContainerFlipbook.Name = "splitContainerFlipbook";
            // 
            // splitContainerFlipbook.Panel1
            // 
            this.splitContainerFlipbook.Panel1.Controls.Add(this.webBrowser1);
            this.splitContainerFlipbook.Size = new System.Drawing.Size(1172, 641);
            this.splitContainerFlipbook.SplitterDistance = 1001;
            this.splitContainerFlipbook.TabIndex = 0;
            // 
            // webBrowser1
            // 
            this.webBrowser1.Dock = Wisej.Web.DockStyle.Fill;
            this.webBrowser1.Location = new System.Drawing.Point(0, 0);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(1001, 641);
            this.webBrowser1.TabIndex = 0;
            // 
            // frmEBookCreation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 19F);
            this.AutoScaleMode = Wisej.Web.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1409, 807);
            this.Controls.Add(this.pnlSideEBookFlipbook);
            this.Controls.Add(this.pnlSideEBookPDFViewer);
            this.Controls.Add(this.pnlSideEBookWriter);
            this.Controls.Add(this.pnlSideEBookCover);
            this.Controls.Add(this.statusBar1);
            this.Controls.Add(this.toolBarEBook);
            this.Controls.Add(this.pnlTop);
            this.Name = "frmEBookCreation";
            this.Text = "eBook Creation";
            this.Load += new System.EventHandler(this.frmEBook_Load);
            this.Resize += new System.EventHandler(this.frmEBookCreation_Resize);
            this.pnlTop.ResumeLayout(false);
            this.pnlSideEBookCover.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEBookCoverImage)).EndInit();
            this.pnlSideEBookWriter.ResumeLayout(false);
            this.splitContainerEBookWriter1.Panel1.ResumeLayout(false);
            this.splitContainerEBookWriter1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerEBookWriter1)).EndInit();
            this.splitContainerEBookWriter1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownChapters)).EndInit();
            this.splitContainerEBookWriter2.Panel1.ResumeLayout(false);
            this.splitContainerEBookWriter2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerEBookWriter2)).EndInit();
            this.splitContainerEBookWriter2.ResumeLayout(false);
            this.tableLayoutPanelEBookWriterChapters.ResumeLayout(false);
            this.tableLayoutPanelEBookWriterChapters.PerformLayout();
            this.tabControlEBookChapters.ResumeLayout(false);
            this.tabPageChapter1.ResumeLayout(false);
            this.tabPageChapter2.ResumeLayout(false);
            this.tabPageChapter3.ResumeLayout(false);
            this.tabPageChapter4.ResumeLayout(false);
            this.tabPageChapter5.ResumeLayout(false);
            this.tabPageChapter6.ResumeLayout(false);
            this.pnlSideEBookPDFViewer.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.pnlSideEBookFlipbook.ResumeLayout(false);
            this.splitContainerFlipbook.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerFlipbook)).EndInit();
            this.splitContainerFlipbook.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Wisej.Web.Panel pnlTop;
        private Wisej.Web.SplitButton splitButtonEBook;
        private Wisej.Web.MenuItem splitButtonMenuItemNewHustle;
        private Wisej.Web.MenuItem splitButtonMenuItemHustleWizard;
        private Wisej.Web.ToolBar toolBarEBook;
        private Wisej.Web.StatusBar statusBar1;
        private Wisej.Web.Panel pnlSideEBookCover;
        private Wisej.Web.Panel pnlSideEBookWriter;
        private Wisej.Web.Panel pnlSideEBookPDFViewer;
        private Wisej.Web.Panel pnlSideEBookFlipbook;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.PictureBox pictureBoxEBookCoverImage;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel2;
        private Wisej.Web.TextBox txtEBookCoverShortDescription;
        private Wisej.Web.TextBox txtEBookCoverByline;
        private Wisej.Web.TextBox txtEBookCoverTitle;
        private Wisej.Web.SplitContainer splitContainerEBookWriter1;
        private Wisej.Web.SplitContainer splitContainerEBookWriter2;
        private Wisej.Web.GroupBox groupBox2;
        private Wisej.Web.Label label11;
        private Wisej.Web.Upload uploadEBookCover;
        private Wisej.Web.TabControl tabControlEBookChapters;
        private Wisej.Web.TabPage tabPageChapter1;
        private Wisej.Web.Ext.TinyEditor.TinyEditor tinyEditorChapter1;
        private Wisej.Web.Label lblBookChapter01;
        private Wisej.Web.Button btnGenBookChapter01;
        private Wisej.Web.TabPage tabPageChapter2;
        private Wisej.Web.Ext.TinyEditor.TinyEditor tinyEditorChapter2;
        private Wisej.Web.Label lblBookChapter02;
        private Wisej.Web.Button btnGenBookChapter02;
        private Wisej.Web.TabPage tabPageChapter3;
        private Wisej.Web.Ext.TinyEditor.TinyEditor tinyEditorChapter3;
        private Wisej.Web.Label lblBookChapter03;
        private Wisej.Web.Button btnGenBookChapter03;
        private Wisej.Web.TabPage tabPageChapter4;
        private Wisej.Web.Ext.TinyEditor.TinyEditor tinyEditorChapter4;
        private Wisej.Web.Label lblBookChapter04;
        private Wisej.Web.Button btnGenBookChapter04;
        private Wisej.Web.TabPage tabPageChapter5;
        private Wisej.Web.Ext.TinyEditor.TinyEditor tinyEditorChapter5;
        private Wisej.Web.Label lblBookChapter05;
        private Wisej.Web.Button btnGenBookChapter05;
        private Wisej.Web.TabPage tabPageChapter6;
        private Wisej.Web.Ext.TinyEditor.TinyEditor tinyEditorChapter6;
        private Wisej.Web.Label lblBookChapter06;
        private Wisej.Web.Button btnGenBookChapter06;
        private Wisej.Web.TableLayoutPanel tableLayoutPanelEBookWriterChapters;
        private Wisej.Web.CheckBox chkChapter6;
        private Wisej.Web.CheckBox chkChapter5;
        private Wisej.Web.CheckBox chkChapter4;
        private Wisej.Web.CheckBox chkChapter3;
        private Wisej.Web.CheckBox chkChapter2;
        private Wisej.Web.TextBox txtBookChapter04;
        private Wisej.Web.CheckBox chkChapter1;
        private Wisej.Web.TextBox txtBookChapter06;
        private Wisej.Web.TextBox txtBookChapter05;
        private Wisej.Web.TextBox txtBookChapter03;
        private Wisej.Web.TextBox txtBookChapter02;
        private Wisej.Web.TextBox txtBookChapter01;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel3;
        private Wisej.Web.Button btnGenBookLayout;
        private Wisej.Web.NumericUpDown numericUpDownChapters;
        private Wisej.Web.TextBox txtEBookWriterBookSummary;
        private Wisej.Web.TextBox txtEBookWriterAIPrompt;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel4;
        private Wisej.Web.TextBox txtEBookCoverVideoURL;
        private Wisej.Web.TextBox txtEBookCoverSerial;
        private Wisej.Web.TextBox txtEBookCoverPublisher;
        private Wisej.Web.ComboBox cboEBookCoverBookFormat;
        private Wisej.Web.TextBox txtEBookCoverAuthor;
        private Wisej.Web.TextBox txtEBookCoverSaveAs;
        private Wisej.Web.Button btnEBookCoverSaveAndNextStep;
        private Wisej.Web.Line line1;
        private Wisej.Web.FlowLayoutPanel flowLayoutPanelEBook;
        private Wisej.Web.Button btnGenerateChapterTitles;
        private Wisej.Web.Label lblEBookStatus;
        private Wisej.Web.GroupBox groupBox1;
        private Wisej.Web.RadioButton radioEBookWriterExtraLong;
        private Wisej.Web.RadioButton radioEBookWriterDefaultLength;
        private Wisej.Web.TextBox txtEBookID;
        private Wisej.Web.TextBox textBox2;
        private Wisej.Web.SplitContainer splitContainer1;
        private Wisej.Web.Button btnGenBookFinalPDF;
        private Wisej.Web.Button btnGenBookNextStepPDF;
        private Wisej.Web.SplitContainer splitContainer2;
        private Wisej.Web.PdfViewer pdfViewer1;
        private Wisej.Web.Button btnNextStepFlipbook;
        private Wisej.Web.SplitContainer splitContainerFlipbook;
        private Wisej.Web.WebBrowser webBrowser1;
        private Wisej.Web.CheckBox chkSaveSideEBookCover;
        private Wisej.Web.CheckBox chkSaveSideEBookWriter;
    }
}