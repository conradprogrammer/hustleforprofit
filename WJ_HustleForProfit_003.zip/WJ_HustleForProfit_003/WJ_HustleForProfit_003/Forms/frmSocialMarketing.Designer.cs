﻿namespace WJ_HustleForProfit_003.Forms
{
    partial class frmSocialMarketing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Wisej.Web.ComponentTool componentTool49 = new Wisej.Web.ComponentTool();
            Wisej.Web.ComponentTool componentTool50 = new Wisej.Web.ComponentTool();
            Wisej.Web.ComponentTool componentTool51 = new Wisej.Web.ComponentTool();
            Wisej.Web.ComponentTool componentTool52 = new Wisej.Web.ComponentTool();
            this.statusBar1 = new Wisej.Web.StatusBar();
            this.pnlTop = new Wisej.Web.Panel();
            this.flowLayoutPanelSocialMarketing = new Wisej.Web.FlowLayoutPanel();
            this.splitButtonSocialMedia = new Wisej.Web.SplitButton();
            this.splitButtonMenuItemNewHustle = new Wisej.Web.MenuItem();
            this.splitButtonMenuItemHustleWizard = new Wisej.Web.MenuItem();
            this.pnlSocialMedia = new Wisej.Web.Panel();
            this.splitContainerSocialMarketing1 = new Wisej.Web.SplitContainer();
            this.tableLayoutPanelButtons = new Wisej.Web.TableLayoutPanel();
            this.btnTwitter = new Wisej.Web.Button();
            this.splitContainerSocialMarketing2 = new Wisej.Web.SplitContainer();
            this.tableLayoutPanelCampaign = new Wisej.Web.TableLayoutPanel();
            this.chkYoutubeTweets = new Wisej.Web.CheckBox();
            this.pnlNumericUpDowns = new Wisej.Web.Panel();
            this.numericUpDownWeeks = new Wisej.Web.NumericUpDown();
            this.numericUpDownPostsPerDay = new Wisej.Web.NumericUpDown();
            this.dateTimeCampaignStart = new Wisej.Web.DateTimePicker();
            this.txtCampaignName = new Wisej.Web.TextBox();
            this.txtCampaignTitle = new Wisej.Web.TextBox();
            this.txtTargetAudience = new Wisej.Web.TextBox();
            this.txtCampaignNarrative = new Wisej.Web.TextBox();
            this.txtCampaignKeywords = new Wisej.Web.TextBox();
            this.btnGenerateFinal = new Wisej.Web.Button();
            this.btnGenerateDraft = new Wisej.Web.Button();
            this.splitContainerSocialMarketing3 = new Wisej.Web.SplitContainer();
            this.tinyEditor1 = new Wisej.Web.Ext.TinyEditor.TinyEditor();
            this.contextMenuTinyEditor = new Wisej.Web.ContextMenu(this.components);
            this.menuItem1 = new Wisej.Web.MenuItem();
            this.menuItem2 = new Wisej.Web.MenuItem();
            this.splitContainer1 = new Wisej.Web.SplitContainer();
            this.panel1 = new Wisej.Web.Panel();
            this.lbYouTubeVideoLinks = new Wisej.Web.ListBox();
            this.toolBarEBook = new Wisej.Web.ToolBar();
            this.button1 = new Wisej.Web.Button();
            this.button2 = new Wisej.Web.Button();
            this.button3 = new Wisej.Web.Button();
            this.button4 = new Wisej.Web.Button();
            this.pnlTop.SuspendLayout();
            this.flowLayoutPanelSocialMarketing.SuspendLayout();
            this.pnlSocialMedia.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerSocialMarketing1)).BeginInit();
            this.splitContainerSocialMarketing1.Panel1.SuspendLayout();
            this.splitContainerSocialMarketing1.Panel2.SuspendLayout();
            this.splitContainerSocialMarketing1.SuspendLayout();
            this.tableLayoutPanelButtons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerSocialMarketing2)).BeginInit();
            this.splitContainerSocialMarketing2.Panel1.SuspendLayout();
            this.splitContainerSocialMarketing2.Panel2.SuspendLayout();
            this.splitContainerSocialMarketing2.SuspendLayout();
            this.tableLayoutPanelCampaign.SuspendLayout();
            this.pnlNumericUpDowns.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownWeeks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPostsPerDay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerSocialMarketing3)).BeginInit();
            this.splitContainerSocialMarketing3.Panel1.SuspendLayout();
            this.splitContainerSocialMarketing3.Panel2.SuspendLayout();
            this.splitContainerSocialMarketing3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusBar1
            // 
            this.statusBar1.Location = new System.Drawing.Point(0, 807);
            this.statusBar1.Name = "statusBar1";
            this.statusBar1.Size = new System.Drawing.Size(1240, 22);
            this.statusBar1.TabIndex = 0;
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.pnlTop.Controls.Add(this.flowLayoutPanelSocialMarketing);
            this.pnlTop.Dock = Wisej.Web.DockStyle.Top;
            this.pnlTop.HeaderSize = 25;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.ShowCloseButton = false;
            this.pnlTop.Size = new System.Drawing.Size(1240, 112);
            this.pnlTop.TabIndex = 2;
            // 
            // flowLayoutPanelSocialMarketing
            // 
            this.flowLayoutPanelSocialMarketing.AutoScroll = true;
            this.flowLayoutPanelSocialMarketing.Controls.Add(this.splitButtonSocialMedia);
            this.flowLayoutPanelSocialMarketing.Dock = Wisej.Web.DockStyle.Fill;
            this.flowLayoutPanelSocialMarketing.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanelSocialMarketing.Name = "flowLayoutPanelSocialMarketing";
            this.flowLayoutPanelSocialMarketing.Padding = new Wisej.Web.Padding(3);
            this.flowLayoutPanelSocialMarketing.ScrollBars = Wisej.Web.ScrollBars.Horizontal;
            this.flowLayoutPanelSocialMarketing.ShowCloseButton = false;
            this.flowLayoutPanelSocialMarketing.Size = new System.Drawing.Size(1238, 110);
            this.flowLayoutPanelSocialMarketing.TabIndex = 0;
            // 
            // splitButtonSocialMedia
            // 
            this.splitButtonSocialMedia.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.splitButtonSocialMedia.Location = new System.Drawing.Point(6, 6);
            this.splitButtonSocialMedia.MenuItems.AddRange(new Wisej.Web.MenuItem[] {
            this.splitButtonMenuItemNewHustle,
            this.splitButtonMenuItemHustleWizard});
            this.splitButtonSocialMedia.Name = "splitButtonSocialMedia";
            this.splitButtonSocialMedia.Size = new System.Drawing.Size(100, 100);
            this.splitButtonSocialMedia.TabIndex = 1;
            this.splitButtonSocialMedia.Text = "Start New Campaign";
            this.splitButtonSocialMedia.Click += new System.EventHandler(this.splitButtonSocialMedia_Click);
            // 
            // splitButtonMenuItemNewHustle
            // 
            this.splitButtonMenuItemNewHustle.Index = 0;
            this.splitButtonMenuItemNewHustle.Name = "splitButtonMenuItemNewHustle";
            this.splitButtonMenuItemNewHustle.Text = "Create New Campaign";
            // 
            // splitButtonMenuItemHustleWizard
            // 
            this.splitButtonMenuItemHustleWizard.Index = 1;
            this.splitButtonMenuItemHustleWizard.Name = "splitButtonMenuItemHustleWizard";
            this.splitButtonMenuItemHustleWizard.Text = "New Campaign Wizard";
            // 
            // pnlSocialMedia
            // 
            this.pnlSocialMedia.Controls.Add(this.splitContainerSocialMarketing1);
            this.pnlSocialMedia.Controls.Add(this.toolBarEBook);
            this.pnlSocialMedia.Dock = Wisej.Web.DockStyle.Fill;
            this.pnlSocialMedia.Location = new System.Drawing.Point(0, 112);
            this.pnlSocialMedia.Name = "pnlSocialMedia";
            this.pnlSocialMedia.ShowCloseButton = false;
            this.pnlSocialMedia.Size = new System.Drawing.Size(1240, 695);
            this.pnlSocialMedia.TabIndex = 3;
            this.pnlSocialMedia.Visible = false;
            // 
            // splitContainerSocialMarketing1
            // 
            this.splitContainerSocialMarketing1.Dock = Wisej.Web.DockStyle.Fill;
            this.splitContainerSocialMarketing1.Location = new System.Drawing.Point(0, 32);
            this.splitContainerSocialMarketing1.Name = "splitContainerSocialMarketing1";
            // 
            // splitContainerSocialMarketing1.Panel1
            // 
            this.splitContainerSocialMarketing1.Panel1.Controls.Add(this.tableLayoutPanelButtons);
            // 
            // splitContainerSocialMarketing1.Panel2
            // 
            this.splitContainerSocialMarketing1.Panel2.Controls.Add(this.splitContainerSocialMarketing2);
            this.splitContainerSocialMarketing1.Size = new System.Drawing.Size(1240, 663);
            this.splitContainerSocialMarketing1.SplitterDistance = 223;
            this.splitContainerSocialMarketing1.TabIndex = 6;
            // 
            // tableLayoutPanelButtons
            // 
            this.tableLayoutPanelButtons.ColumnCount = 1;
            this.tableLayoutPanelButtons.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanelButtons.Controls.Add(this.button4, 0, 4);
            this.tableLayoutPanelButtons.Controls.Add(this.button3, 0, 3);
            this.tableLayoutPanelButtons.Controls.Add(this.button2, 0, 2);
            this.tableLayoutPanelButtons.Controls.Add(this.button1, 0, 1);
            this.tableLayoutPanelButtons.Controls.Add(this.btnTwitter, 0, 0);
            this.tableLayoutPanelButtons.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanelButtons.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelButtons.Name = "tableLayoutPanelButtons";
            this.tableLayoutPanelButtons.Padding = new Wisej.Web.Padding(10);
            this.tableLayoutPanelButtons.RowCount = 8;
            this.tableLayoutPanelButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 75F));
            this.tableLayoutPanelButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 75F));
            this.tableLayoutPanelButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 75F));
            this.tableLayoutPanelButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 75F));
            this.tableLayoutPanelButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 75F));
            this.tableLayoutPanelButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 75F));
            this.tableLayoutPanelButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 75F));
            this.tableLayoutPanelButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 75F));
            this.tableLayoutPanelButtons.ShowCloseButton = false;
            this.tableLayoutPanelButtons.Size = new System.Drawing.Size(221, 661);
            this.tableLayoutPanelButtons.TabIndex = 0;
            // 
            // btnTwitter
            // 
            this.btnTwitter.BackColor = System.Drawing.Color.FromName("@buttonFace");
            this.btnTwitter.Dock = Wisej.Web.DockStyle.Fill;
            this.btnTwitter.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnTwitter.ImageSource = "resource.wx/Wisej.Ext.ElegantIcons/twitter.svg";
            this.btnTwitter.Location = new System.Drawing.Point(13, 13);
            this.btnTwitter.Name = "btnTwitter";
            this.btnTwitter.Size = new System.Drawing.Size(195, 69);
            this.btnTwitter.TabIndex = 0;
            this.btnTwitter.Text = "Twitter (X)";
            this.btnTwitter.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTwitter.Click += new System.EventHandler(this.btnTwitter_Click);
            // 
            // splitContainerSocialMarketing2
            // 
            this.splitContainerSocialMarketing2.Dock = Wisej.Web.DockStyle.Fill;
            this.splitContainerSocialMarketing2.Location = new System.Drawing.Point(0, 0);
            this.splitContainerSocialMarketing2.Name = "splitContainerSocialMarketing2";
            // 
            // splitContainerSocialMarketing2.Panel1
            // 
            this.splitContainerSocialMarketing2.Panel1.Controls.Add(this.tableLayoutPanelCampaign);
            // 
            // splitContainerSocialMarketing2.Panel2
            // 
            this.splitContainerSocialMarketing2.Panel2.Controls.Add(this.splitContainerSocialMarketing3);
            this.splitContainerSocialMarketing2.Size = new System.Drawing.Size(1008, 663);
            this.splitContainerSocialMarketing2.SplitterDistance = 307;
            this.splitContainerSocialMarketing2.TabIndex = 0;
            // 
            // tableLayoutPanelCampaign
            // 
            this.tableLayoutPanelCampaign.ColumnCount = 1;
            this.tableLayoutPanelCampaign.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanelCampaign.Controls.Add(this.chkYoutubeTweets, 0, 7);
            this.tableLayoutPanelCampaign.Controls.Add(this.pnlNumericUpDowns, 0, 3);
            this.tableLayoutPanelCampaign.Controls.Add(this.dateTimeCampaignStart, 0, 2);
            this.tableLayoutPanelCampaign.Controls.Add(this.txtCampaignName, 0, 1);
            this.tableLayoutPanelCampaign.Controls.Add(this.txtCampaignTitle, 0, 0);
            this.tableLayoutPanelCampaign.Controls.Add(this.txtTargetAudience, 0, 4);
            this.tableLayoutPanelCampaign.Controls.Add(this.txtCampaignNarrative, 0, 5);
            this.tableLayoutPanelCampaign.Controls.Add(this.txtCampaignKeywords, 0, 6);
            this.tableLayoutPanelCampaign.Controls.Add(this.btnGenerateFinal, 0, 9);
            this.tableLayoutPanelCampaign.Controls.Add(this.btnGenerateDraft, 0, 8);
            this.tableLayoutPanelCampaign.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanelCampaign.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelCampaign.Name = "tableLayoutPanelCampaign";
            this.tableLayoutPanelCampaign.Padding = new Wisej.Web.Padding(10);
            this.tableLayoutPanelCampaign.RowCount = 10;
            this.tableLayoutPanelCampaign.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 75F));
            this.tableLayoutPanelCampaign.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 55F));
            this.tableLayoutPanelCampaign.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 55F));
            this.tableLayoutPanelCampaign.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 55F));
            this.tableLayoutPanelCampaign.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 75F));
            this.tableLayoutPanelCampaign.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 75F));
            this.tableLayoutPanelCampaign.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 75F));
            this.tableLayoutPanelCampaign.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 75F));
            this.tableLayoutPanelCampaign.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanelCampaign.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanelCampaign.ShowCloseButton = false;
            this.tableLayoutPanelCampaign.Size = new System.Drawing.Size(305, 661);
            this.tableLayoutPanelCampaign.TabIndex = 0;
            // 
            // chkYoutubeTweets
            // 
            this.chkYoutubeTweets.Dock = Wisej.Web.DockStyle.Bottom;
            this.chkYoutubeTweets.Location = new System.Drawing.Point(13, 505);
            this.chkYoutubeTweets.Name = "chkYoutubeTweets";
            this.chkYoutubeTweets.Size = new System.Drawing.Size(279, 23);
            this.chkYoutubeTweets.TabIndex = 13;
            this.chkYoutubeTweets.Text = "Use Youtube to make Tweets";
            // 
            // pnlNumericUpDowns
            // 
            this.pnlNumericUpDowns.Controls.Add(this.numericUpDownWeeks);
            this.pnlNumericUpDowns.Controls.Add(this.numericUpDownPostsPerDay);
            this.pnlNumericUpDowns.Dock = Wisej.Web.DockStyle.Fill;
            this.pnlNumericUpDowns.Location = new System.Drawing.Point(13, 198);
            this.pnlNumericUpDowns.Name = "pnlNumericUpDowns";
            this.pnlNumericUpDowns.ShowCloseButton = false;
            this.pnlNumericUpDowns.Size = new System.Drawing.Size(279, 49);
            this.pnlNumericUpDowns.TabIndex = 12;
            // 
            // numericUpDownWeeks
            // 
            this.numericUpDownWeeks.Dock = Wisej.Web.DockStyle.Left;
            this.numericUpDownWeeks.LabelText = "Campaign Weeks:";
            this.numericUpDownWeeks.Location = new System.Drawing.Point(0, 0);
            this.numericUpDownWeeks.Minimum = new decimal(1);
            this.numericUpDownWeeks.Name = "numericUpDownWeeks";
            this.numericUpDownWeeks.Size = new System.Drawing.Size(143, 49);
            this.numericUpDownWeeks.TabIndex = 7;
            this.numericUpDownWeeks.Value = new decimal(1);
            // 
            // numericUpDownPostsPerDay
            // 
            this.numericUpDownPostsPerDay.Dock = Wisej.Web.DockStyle.Right;
            this.numericUpDownPostsPerDay.LabelText = "Postings per Day:";
            this.numericUpDownPostsPerDay.Location = new System.Drawing.Point(151, 0);
            this.numericUpDownPostsPerDay.Minimum = new decimal(1);
            this.numericUpDownPostsPerDay.Name = "numericUpDownPostsPerDay";
            this.numericUpDownPostsPerDay.Size = new System.Drawing.Size(128, 49);
            this.numericUpDownPostsPerDay.TabIndex = 3;
            this.numericUpDownPostsPerDay.Value = new decimal(1);
            // 
            // dateTimeCampaignStart
            // 
            this.dateTimeCampaignStart.Dock = Wisej.Web.DockStyle.Fill;
            this.dateTimeCampaignStart.Format = Wisej.Web.DateTimePickerFormat.Short;
            this.dateTimeCampaignStart.LabelText = "Campaign Start Date:";
            this.dateTimeCampaignStart.Location = new System.Drawing.Point(13, 143);
            this.dateTimeCampaignStart.Name = "dateTimeCampaignStart";
            this.dateTimeCampaignStart.Size = new System.Drawing.Size(279, 49);
            this.dateTimeCampaignStart.TabIndex = 11;
            // 
            // txtCampaignName
            // 
            this.txtCampaignName.AutoSize = false;
            this.txtCampaignName.Dock = Wisej.Web.DockStyle.Fill;
            this.txtCampaignName.LabelText = "Campaign Name (max 15 char):";
            this.txtCampaignName.Location = new System.Drawing.Point(13, 88);
            this.txtCampaignName.Name = "txtCampaignName";
            this.txtCampaignName.Size = new System.Drawing.Size(279, 49);
            this.txtCampaignName.TabIndex = 10;
            this.txtCampaignName.Watermark = "i.e. Campaign 1";
            // 
            // txtCampaignTitle
            // 
            this.txtCampaignTitle.AutoSize = false;
            this.txtCampaignTitle.Dock = Wisej.Web.DockStyle.Fill;
            this.txtCampaignTitle.LabelText = "Campaign Title:";
            this.txtCampaignTitle.Location = new System.Drawing.Point(13, 13);
            this.txtCampaignTitle.Multiline = true;
            this.txtCampaignTitle.Name = "txtCampaignTitle";
            this.txtCampaignTitle.Size = new System.Drawing.Size(279, 69);
            this.txtCampaignTitle.TabIndex = 0;
            componentTool49.ImageSource = "Icons\\ado-ai-16.png";
            this.txtCampaignTitle.Tools.AddRange(new Wisej.Web.ComponentTool[] {
            componentTool49});
            // 
            // txtTargetAudience
            // 
            this.txtTargetAudience.AutoSize = false;
            this.txtTargetAudience.Dock = Wisej.Web.DockStyle.Fill;
            this.txtTargetAudience.LabelText = "Target Audience:";
            this.txtTargetAudience.Location = new System.Drawing.Point(13, 253);
            this.txtTargetAudience.Multiline = true;
            this.txtTargetAudience.Name = "txtTargetAudience";
            this.txtTargetAudience.Size = new System.Drawing.Size(279, 69);
            this.txtTargetAudience.TabIndex = 8;
            componentTool50.ImageSource = "Icons\\ado-ai-16.png";
            componentTool50.ToolTipText = "Do it for me with AI";
            this.txtTargetAudience.Tools.AddRange(new Wisej.Web.ComponentTool[] {
            componentTool50});
            // 
            // txtCampaignNarrative
            // 
            this.txtCampaignNarrative.AutoSize = false;
            this.txtCampaignNarrative.Dock = Wisej.Web.DockStyle.Fill;
            this.txtCampaignNarrative.LabelText = "Campaign Narrative:";
            this.txtCampaignNarrative.Location = new System.Drawing.Point(13, 328);
            this.txtCampaignNarrative.Multiline = true;
            this.txtCampaignNarrative.Name = "txtCampaignNarrative";
            this.txtCampaignNarrative.Size = new System.Drawing.Size(279, 69);
            this.txtCampaignNarrative.TabIndex = 4;
            componentTool51.ImageSource = "Icons\\ado-ai-16.png";
            componentTool51.ToolTipText = "Do it for me with AI";
            this.txtCampaignNarrative.Tools.AddRange(new Wisej.Web.ComponentTool[] {
            componentTool51});
            // 
            // txtCampaignKeywords
            // 
            this.txtCampaignKeywords.AutoSize = false;
            this.txtCampaignKeywords.Dock = Wisej.Web.DockStyle.Fill;
            this.txtCampaignKeywords.LabelText = "Keywords:";
            this.txtCampaignKeywords.Location = new System.Drawing.Point(13, 403);
            this.txtCampaignKeywords.Multiline = true;
            this.txtCampaignKeywords.Name = "txtCampaignKeywords";
            this.txtCampaignKeywords.Size = new System.Drawing.Size(279, 69);
            this.txtCampaignKeywords.TabIndex = 5;
            componentTool52.ImageSource = "Icons\\ado-ai-16.png";
            componentTool52.ToolTipText = "Do it for me with AI";
            this.txtCampaignKeywords.Tools.AddRange(new Wisej.Web.ComponentTool[] {
            componentTool52});
            // 
            // btnGenerateFinal
            // 
            this.btnGenerateFinal.Dock = Wisej.Web.DockStyle.Fill;
            this.btnGenerateFinal.Location = new System.Drawing.Point(13, 594);
            this.btnGenerateFinal.Name = "btnGenerateFinal";
            this.btnGenerateFinal.Size = new System.Drawing.Size(279, 54);
            this.btnGenerateFinal.TabIndex = 9;
            this.btnGenerateFinal.Text = "Generate and Save Final Version using Paid Credits";
            this.btnGenerateFinal.Click += new System.EventHandler(this.btnGenerateFinal_Click);
            // 
            // btnGenerateDraft
            // 
            this.btnGenerateDraft.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.btnGenerateDraft.Dock = Wisej.Web.DockStyle.Fill;
            this.btnGenerateDraft.Location = new System.Drawing.Point(13, 534);
            this.btnGenerateDraft.Name = "btnGenerateDraft";
            this.btnGenerateDraft.Size = new System.Drawing.Size(279, 54);
            this.btnGenerateDraft.TabIndex = 6;
            this.btnGenerateDraft.Text = "Generate Draft Version using Free Points";
            this.btnGenerateDraft.Click += new System.EventHandler(this.btnGenerateDraft_Click);
            // 
            // splitContainerSocialMarketing3
            // 
            this.splitContainerSocialMarketing3.Dock = Wisej.Web.DockStyle.Fill;
            this.splitContainerSocialMarketing3.Location = new System.Drawing.Point(0, 0);
            this.splitContainerSocialMarketing3.Name = "splitContainerSocialMarketing3";
            // 
            // splitContainerSocialMarketing3.Panel1
            // 
            this.splitContainerSocialMarketing3.Panel1.Controls.Add(this.tinyEditor1);
            // 
            // splitContainerSocialMarketing3.Panel2
            // 
            this.splitContainerSocialMarketing3.Panel2.Controls.Add(this.splitContainer1);
            this.splitContainerSocialMarketing3.Size = new System.Drawing.Size(692, 663);
            this.splitContainerSocialMarketing3.SplitterDistance = 370;
            this.splitContainerSocialMarketing3.TabIndex = 0;
            // 
            // tinyEditor1
            // 
            this.tinyEditor1.AccessibleRole = Wisej.Web.AccessibleRole.None;
            this.tinyEditor1.ContextMenu = this.contextMenuTinyEditor;
            this.tinyEditor1.Dock = Wisej.Web.DockStyle.Fill;
            this.tinyEditor1.Name = "tinyEditor1";
            this.tinyEditor1.Size = new System.Drawing.Size(368, 661);
            this.tinyEditor1.SourceText = "HTML Source";
            this.tinyEditor1.TabIndex = 0;
            this.tinyEditor1.WysiwygText = "HTML Viewer";
            // 
            // contextMenuTinyEditor
            // 
            this.contextMenuTinyEditor.MenuItems.AddRange(new Wisej.Web.MenuItem[] {
            this.menuItem1,
            this.menuItem2});
            this.contextMenuTinyEditor.Name = "contextMenuTinyEditor";
            this.contextMenuTinyEditor.RightToLeft = Wisej.Web.RightToLeft.No;
            // 
            // menuItem1
            // 
            this.menuItem1.Index = 0;
            this.menuItem1.Name = "menuItem1";
            this.menuItem1.Text = "Copy";
            // 
            // menuItem2
            // 
            this.menuItem2.Index = 1;
            this.menuItem2.Name = "menuItem2";
            this.menuItem2.Text = "Paste";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = Wisej.Web.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = Wisej.Web.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.panel1);
            this.splitContainer1.Size = new System.Drawing.Size(313, 663);
            this.splitContainer1.SplitterDistance = 331;
            this.splitContainer1.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbYouTubeVideoLinks);
            this.panel1.Dock = Wisej.Web.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.ShowCloseButton = false;
            this.panel1.ShowHeader = true;
            this.panel1.Size = new System.Drawing.Size(311, 329);
            this.panel1.TabIndex = 0;
            this.panel1.Text = "Video Links";
            // 
            // lbYouTubeVideoLinks
            // 
            this.lbYouTubeVideoLinks.Dock = Wisej.Web.DockStyle.Fill;
            this.lbYouTubeVideoLinks.Location = new System.Drawing.Point(0, 0);
            this.lbYouTubeVideoLinks.Name = "lbYouTubeVideoLinks";
            this.lbYouTubeVideoLinks.Size = new System.Drawing.Size(311, 301);
            this.lbYouTubeVideoLinks.TabIndex = 13;
            this.lbYouTubeVideoLinks.Click += new System.EventHandler(this.lbYouTubeVideoLinks_Click);
            // 
            // toolBarEBook
            // 
            this.toolBarEBook.Location = new System.Drawing.Point(0, 0);
            this.toolBarEBook.Name = "toolBarEBook";
            this.toolBarEBook.Size = new System.Drawing.Size(1240, 32);
            this.toolBarEBook.TabIndex = 5;
            this.toolBarEBook.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.button1.Dock = Wisej.Web.DockStyle.Fill;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.ImageSource = "resource.wx/Wisej.Ext.IonicIcons/logo-youtube.svg";
            this.button1.Location = new System.Drawing.Point(13, 88);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(195, 69);
            this.button1.TabIndex = 1;
            this.button1.Text = "Twitter + Youtube";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // button2
            // 
            this.button2.Dock = Wisej.Web.DockStyle.Fill;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button2.ImageSource = "resource.wx/Wisej.Ext.IonicIcons/logo-facebook.svg";
            this.button2.Location = new System.Drawing.Point(13, 163);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(195, 69);
            this.button2.TabIndex = 2;
            this.button2.Text = "Facebook";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // button3
            // 
            this.button3.Dock = Wisej.Web.DockStyle.Fill;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button3.ImageSource = "resource.wx/Wisej.Ext.IonicIcons/logo-instagram.svg";
            this.button3.Location = new System.Drawing.Point(13, 238);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(195, 69);
            this.button3.TabIndex = 3;
            this.button3.Text = "Instagram";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // button4
            // 
            this.button4.Dock = Wisej.Web.DockStyle.Fill;
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button4.ImageSource = "resource.wx/Wisej.Ext.IonicIcons/logo-tiktok.svg";
            this.button4.Location = new System.Drawing.Point(13, 313);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(195, 69);
            this.button4.TabIndex = 4;
            this.button4.Text = "TikTok";
            this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // frmSocialMarketing
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 19F);
            this.AutoScaleMode = Wisej.Web.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1240, 829);
            this.Controls.Add(this.pnlSocialMedia);
            this.Controls.Add(this.pnlTop);
            this.Controls.Add(this.statusBar1);
            this.Name = "frmSocialMarketing";
            this.Text = "Social Marketing";
            this.Load += new System.EventHandler(this.frmSocialMedia_Load);
            this.pnlTop.ResumeLayout(false);
            this.flowLayoutPanelSocialMarketing.ResumeLayout(false);
            this.pnlSocialMedia.ResumeLayout(false);
            this.pnlSocialMedia.PerformLayout();
            this.splitContainerSocialMarketing1.Panel1.ResumeLayout(false);
            this.splitContainerSocialMarketing1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerSocialMarketing1)).EndInit();
            this.splitContainerSocialMarketing1.ResumeLayout(false);
            this.tableLayoutPanelButtons.ResumeLayout(false);
            this.splitContainerSocialMarketing2.Panel1.ResumeLayout(false);
            this.splitContainerSocialMarketing2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerSocialMarketing2)).EndInit();
            this.splitContainerSocialMarketing2.ResumeLayout(false);
            this.tableLayoutPanelCampaign.ResumeLayout(false);
            this.tableLayoutPanelCampaign.PerformLayout();
            this.pnlNumericUpDowns.ResumeLayout(false);
            this.pnlNumericUpDowns.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownWeeks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPostsPerDay)).EndInit();
            this.splitContainerSocialMarketing3.Panel1.ResumeLayout(false);
            this.splitContainerSocialMarketing3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerSocialMarketing3)).EndInit();
            this.splitContainerSocialMarketing3.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.StatusBar statusBar1;
        private Wisej.Web.Panel pnlTop;
        private Wisej.Web.SplitButton splitButtonSocialMedia;
        private Wisej.Web.MenuItem splitButtonMenuItemNewHustle;
        private Wisej.Web.MenuItem splitButtonMenuItemHustleWizard;
        private Wisej.Web.Panel pnlSocialMedia;
        private Wisej.Web.SplitContainer splitContainerSocialMarketing1;
        private Wisej.Web.TableLayoutPanel tableLayoutPanelButtons;
        private Wisej.Web.Button btnTwitter;
        private Wisej.Web.SplitContainer splitContainerSocialMarketing2;
        private Wisej.Web.TableLayoutPanel tableLayoutPanelCampaign;
        private Wisej.Web.TextBox txtTargetAudience;
        private Wisej.Web.NumericUpDown numericUpDownWeeks;
        private Wisej.Web.Button btnGenerateDraft;
        private Wisej.Web.TextBox txtCampaignKeywords;
        private Wisej.Web.TextBox txtCampaignNarrative;
        private Wisej.Web.TextBox txtCampaignTitle;
        private Wisej.Web.NumericUpDown numericUpDownPostsPerDay;
        private Wisej.Web.SplitContainer splitContainerSocialMarketing3;
        private Wisej.Web.Ext.TinyEditor.TinyEditor tinyEditor1;
        private Wisej.Web.ToolBar toolBarEBook;
        private Wisej.Web.Button btnGenerateFinal;
        private Wisej.Web.FlowLayoutPanel flowLayoutPanelSocialMarketing;
        private Wisej.Web.TextBox txtCampaignName;
        private Wisej.Web.DateTimePicker dateTimeCampaignStart;
        private Wisej.Web.ContextMenu contextMenuTinyEditor;
        private Wisej.Web.MenuItem menuItem1;
        private Wisej.Web.MenuItem menuItem2;
        private Wisej.Web.Panel pnlNumericUpDowns;
        private Wisej.Web.ListBox lbYouTubeVideoLinks;
        private Wisej.Web.SplitContainer splitContainer1;
        private Wisej.Web.Panel panel1;
        private Wisej.Web.CheckBox chkYoutubeTweets;
        private Wisej.Web.Button button1;
        private Wisej.Web.Button button2;
        private Wisej.Web.Button button3;
        private Wisej.Web.Button button4;
    }
}