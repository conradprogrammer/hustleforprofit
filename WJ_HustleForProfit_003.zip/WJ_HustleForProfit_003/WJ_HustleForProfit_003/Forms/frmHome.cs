﻿using System;
using Wisej.Web;

namespace WJ_HustleForProfit_003.Forms
{
    public partial class frmHome : Form
    {
        public frmHome()
        {
            InitializeComponent();
        }
    }
}
