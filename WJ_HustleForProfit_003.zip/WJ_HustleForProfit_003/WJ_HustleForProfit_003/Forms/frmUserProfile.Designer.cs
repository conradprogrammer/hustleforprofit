﻿namespace WJ_HustleForProfit_003.Forms
{
    partial class frmUserProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.btnSaveChanges = new Wisej.Web.Button();
            this.pnlPictureBoxProfile = new Wisej.Web.Panel();
            this.pictureBoxProfilePic = new Wisej.Web.PictureBox();
            this.groupBox1 = new Wisej.Web.GroupBox();
            this.uploadProfilePic = new Wisej.Web.Upload();
            this.txtPassword = new Wisej.Web.TextBox();
            this.txtPrimaryPhone = new Wisej.Web.TextBox();
            this.txtEmailAddress = new Wisej.Web.TextBox();
            this.txtLastname = new Wisej.Web.TextBox();
            this.txtFirstname = new Wisej.Web.TextBox();
            this.tableLayoutPanel2 = new Wisej.Web.TableLayoutPanel();
            this.radioMemberVIP = new Wisej.Web.RadioButton();
            this.radioMemberPremium = new Wisej.Web.RadioButton();
            this.radioMemberBasic = new Wisej.Web.RadioButton();
            this.radioMemberTrial = new Wisej.Web.RadioButton();
            this.splitButtonMembershipUpdate = new Wisej.Web.SplitButton();
            this.menuItem1 = new Wisej.Web.MenuItem();
            this.menuItem2 = new Wisej.Web.MenuItem();
            this.menuItem3 = new Wisej.Web.MenuItem();
            this.tableLayoutPanel3 = new Wisej.Web.TableLayoutPanel();
            this.chkAudiobooks = new Wisej.Web.CheckBox();
            this.chkFlipbooks = new Wisej.Web.CheckBox();
            this.chkMarketingPlans = new Wisej.Web.CheckBox();
            this.chkBusinessPlans = new Wisej.Web.CheckBox();
            this.chkEBooks = new Wisej.Web.CheckBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.pnlPictureBoxProfile.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProfilePic)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.btnSaveChanges, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.pnlPictureBoxProfile, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.groupBox1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtPassword, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.txtPrimaryPhone, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.txtEmailAddress, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtLastname, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtFirstname, 0, 2);
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Left;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.Padding = new Wisej.Web.Padding(10);
            this.tableLayoutPanel1.RowCount = 11;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 170F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.ShowCloseButton = false;
            this.tableLayoutPanel1.Size = new System.Drawing.Size(258, 604);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // btnSaveChanges
            // 
            this.btnSaveChanges.Dock = Wisej.Web.DockStyle.Bottom;
            this.btnSaveChanges.Location = new System.Drawing.Point(13, 560);
            this.btnSaveChanges.Name = "btnSaveChanges";
            this.btnSaveChanges.Size = new System.Drawing.Size(230, 37);
            this.btnSaveChanges.TabIndex = 9;
            this.btnSaveChanges.Text = "Save Changes";
            this.btnSaveChanges.Click += new System.EventHandler(this.btnSaveChanges_Click);
            // 
            // pnlPictureBoxProfile
            // 
            this.pnlPictureBoxProfile.Controls.Add(this.pictureBoxProfilePic);
            this.pnlPictureBoxProfile.Dock = Wisej.Web.DockStyle.Fill;
            this.pnlPictureBoxProfile.Location = new System.Drawing.Point(13, 13);
            this.pnlPictureBoxProfile.Name = "pnlPictureBoxProfile";
            this.pnlPictureBoxProfile.ShowCloseButton = false;
            this.pnlPictureBoxProfile.Size = new System.Drawing.Size(230, 164);
            this.pnlPictureBoxProfile.TabIndex = 8;
            // 
            // pictureBoxProfilePic
            // 
            this.pictureBoxProfilePic.Location = new System.Drawing.Point(44, 6);
            this.pictureBoxProfilePic.Name = "pictureBoxProfilePic";
            this.pictureBoxProfilePic.Size = new System.Drawing.Size(150, 150);
            this.pictureBoxProfilePic.SizeMode = Wisej.Web.PictureBoxSizeMode.StretchImage;
            this.pictureBoxProfilePic.Tag = ".jpg or .png images 150x150px";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.uploadProfilePic);
            this.groupBox1.Dock = Wisej.Web.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(13, 183);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(230, 54);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.Text = "Upload Profile Picture (.jpg or .png)";
            // 
            // uploadProfilePic
            // 
            this.uploadProfilePic.Dock = Wisej.Web.DockStyle.Fill;
            this.uploadProfilePic.Location = new System.Drawing.Point(3, 21);
            this.uploadProfilePic.Name = "uploadProfilePic";
            this.uploadProfilePic.Size = new System.Drawing.Size(224, 30);
            this.uploadProfilePic.TabIndex = 8;
            this.uploadProfilePic.Text = "Upload";
            // 
            // txtPassword
            // 
            this.txtPassword.Dock = Wisej.Web.DockStyle.Fill;
            this.txtPassword.LabelText = "Password:";
            this.txtPassword.Location = new System.Drawing.Point(13, 483);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(230, 54);
            this.txtPassword.TabIndex = 5;
            // 
            // txtPrimaryPhone
            // 
            this.txtPrimaryPhone.Dock = Wisej.Web.DockStyle.Fill;
            this.txtPrimaryPhone.LabelText = "Primary Phone(with SMS)";
            this.txtPrimaryPhone.Location = new System.Drawing.Point(13, 423);
            this.txtPrimaryPhone.Name = "txtPrimaryPhone";
            this.txtPrimaryPhone.Size = new System.Drawing.Size(230, 54);
            this.txtPrimaryPhone.TabIndex = 4;
            // 
            // txtEmailAddress
            // 
            this.txtEmailAddress.Dock = Wisej.Web.DockStyle.Fill;
            this.txtEmailAddress.LabelText = "Email Address:";
            this.txtEmailAddress.Location = new System.Drawing.Point(13, 363);
            this.txtEmailAddress.Name = "txtEmailAddress";
            this.txtEmailAddress.Size = new System.Drawing.Size(230, 54);
            this.txtEmailAddress.TabIndex = 3;
            // 
            // txtLastname
            // 
            this.txtLastname.Dock = Wisej.Web.DockStyle.Fill;
            this.txtLastname.LabelText = "Last Name:";
            this.txtLastname.Location = new System.Drawing.Point(13, 303);
            this.txtLastname.Name = "txtLastname";
            this.txtLastname.Size = new System.Drawing.Size(230, 54);
            this.txtLastname.TabIndex = 2;
            // 
            // txtFirstname
            // 
            this.txtFirstname.Dock = Wisej.Web.DockStyle.Fill;
            this.txtFirstname.LabelText = "First Name:";
            this.txtFirstname.Location = new System.Drawing.Point(13, 243);
            this.txtFirstname.Name = "txtFirstname";
            this.txtFirstname.Size = new System.Drawing.Size(230, 54);
            this.txtFirstname.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.radioMemberVIP, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.radioMemberPremium, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.radioMemberBasic, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.radioMemberTrial, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.splitButtonMembershipUpdate, 0, 5);
            this.tableLayoutPanel2.Dock = Wisej.Web.DockStyle.Left;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(258, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.Padding = new Wisej.Web.Padding(10);
            this.tableLayoutPanel2.RowCount = 9;
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 170F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 100F));
            this.tableLayoutPanel2.ShowCloseButton = false;
            this.tableLayoutPanel2.Size = new System.Drawing.Size(258, 604);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // radioMemberVIP
            // 
            this.radioMemberVIP.Dock = Wisej.Web.DockStyle.Bottom;
            this.radioMemberVIP.Enabled = false;
            this.radioMemberVIP.Location = new System.Drawing.Point(13, 394);
            this.radioMemberVIP.Name = "radioMemberVIP";
            this.radioMemberVIP.Size = new System.Drawing.Size(230, 23);
            this.radioMemberVIP.TabIndex = 20;
            this.radioMemberVIP.Text = "VIP Membership";
            // 
            // radioMemberPremium
            // 
            this.radioMemberPremium.Dock = Wisej.Web.DockStyle.Bottom;
            this.radioMemberPremium.Enabled = false;
            this.radioMemberPremium.Location = new System.Drawing.Point(13, 334);
            this.radioMemberPremium.Name = "radioMemberPremium";
            this.radioMemberPremium.Size = new System.Drawing.Size(230, 23);
            this.radioMemberPremium.TabIndex = 19;
            this.radioMemberPremium.Text = "Premium Membership";
            // 
            // radioMemberBasic
            // 
            this.radioMemberBasic.Dock = Wisej.Web.DockStyle.Bottom;
            this.radioMemberBasic.Enabled = false;
            this.radioMemberBasic.Location = new System.Drawing.Point(13, 274);
            this.radioMemberBasic.Name = "radioMemberBasic";
            this.radioMemberBasic.Size = new System.Drawing.Size(230, 23);
            this.radioMemberBasic.TabIndex = 18;
            this.radioMemberBasic.Text = "Basic Membership";
            // 
            // radioMemberTrial
            // 
            this.radioMemberTrial.Checked = true;
            this.radioMemberTrial.Dock = Wisej.Web.DockStyle.Bottom;
            this.radioMemberTrial.Location = new System.Drawing.Point(13, 214);
            this.radioMemberTrial.Name = "radioMemberTrial";
            this.radioMemberTrial.Size = new System.Drawing.Size(230, 23);
            this.radioMemberTrial.TabIndex = 17;
            this.radioMemberTrial.TabStop = true;
            this.radioMemberTrial.Text = "Trial Member";
            // 
            // splitButtonMembershipUpdate
            // 
            this.splitButtonMembershipUpdate.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.splitButtonMembershipUpdate.Dock = Wisej.Web.DockStyle.Bottom;
            this.splitButtonMembershipUpdate.Location = new System.Drawing.Point(13, 448);
            this.splitButtonMembershipUpdate.MenuItems.AddRange(new Wisej.Web.MenuItem[] {
            this.menuItem1,
            this.menuItem2,
            this.menuItem3});
            this.splitButtonMembershipUpdate.Name = "splitButtonMembershipUpdate";
            this.splitButtonMembershipUpdate.Size = new System.Drawing.Size(230, 29);
            this.splitButtonMembershipUpdate.TabIndex = 15;
            this.splitButtonMembershipUpdate.Text = "Upgrade Membership";
            // 
            // menuItem1
            // 
            this.menuItem1.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.menuItem1.Index = 0;
            this.menuItem1.Name = "menuItem1";
            this.menuItem1.SizeMode = Wisej.Web.MenuItemSizeMode.Fill;
            this.menuItem1.Text = "Basic Membership";
            // 
            // menuItem2
            // 
            this.menuItem2.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.menuItem2.Index = 1;
            this.menuItem2.Name = "menuItem2";
            this.menuItem2.SizeMode = Wisej.Web.MenuItemSizeMode.Fill;
            this.menuItem2.Text = "Premium Membership";
            // 
            // menuItem3
            // 
            this.menuItem3.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.menuItem3.Index = 2;
            this.menuItem3.Name = "menuItem3";
            this.menuItem3.SizeMode = Wisej.Web.MenuItemSizeMode.Fill;
            this.menuItem3.Text = "VIP Membership";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.chkAudiobooks, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.chkFlipbooks, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.chkMarketingPlans, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.chkBusinessPlans, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.chkEBooks, 0, 1);
            this.tableLayoutPanel3.Dock = Wisej.Web.DockStyle.Left;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(516, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.Padding = new Wisej.Web.Padding(10);
            this.tableLayoutPanel3.RowCount = 9;
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 170F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 100F));
            this.tableLayoutPanel3.ShowCloseButton = false;
            this.tableLayoutPanel3.Size = new System.Drawing.Size(258, 604);
            this.tableLayoutPanel3.TabIndex = 2;
            // 
            // chkAudiobooks
            // 
            this.chkAudiobooks.Dock = Wisej.Web.DockStyle.Bottom;
            this.chkAudiobooks.Location = new System.Drawing.Point(13, 454);
            this.chkAudiobooks.Name = "chkAudiobooks";
            this.chkAudiobooks.Size = new System.Drawing.Size(230, 23);
            this.chkAudiobooks.TabIndex = 21;
            this.chkAudiobooks.Text = "Enable Audiobooks";
            // 
            // chkFlipbooks
            // 
            this.chkFlipbooks.Dock = Wisej.Web.DockStyle.Bottom;
            this.chkFlipbooks.Location = new System.Drawing.Point(13, 394);
            this.chkFlipbooks.Name = "chkFlipbooks";
            this.chkFlipbooks.Size = new System.Drawing.Size(230, 23);
            this.chkFlipbooks.TabIndex = 20;
            this.chkFlipbooks.Text = "Enable Flipbooks";
            // 
            // chkMarketingPlans
            // 
            this.chkMarketingPlans.Dock = Wisej.Web.DockStyle.Bottom;
            this.chkMarketingPlans.Location = new System.Drawing.Point(13, 334);
            this.chkMarketingPlans.Name = "chkMarketingPlans";
            this.chkMarketingPlans.Size = new System.Drawing.Size(230, 23);
            this.chkMarketingPlans.TabIndex = 19;
            this.chkMarketingPlans.Text = "Enable Social Marketing";
            // 
            // chkBusinessPlans
            // 
            this.chkBusinessPlans.Dock = Wisej.Web.DockStyle.Bottom;
            this.chkBusinessPlans.Location = new System.Drawing.Point(13, 274);
            this.chkBusinessPlans.Name = "chkBusinessPlans";
            this.chkBusinessPlans.Size = new System.Drawing.Size(230, 23);
            this.chkBusinessPlans.TabIndex = 18;
            this.chkBusinessPlans.Text = "Enable Business Plans";
            // 
            // chkEBooks
            // 
            this.chkEBooks.Dock = Wisej.Web.DockStyle.Bottom;
            this.chkEBooks.Enabled = false;
            this.chkEBooks.Location = new System.Drawing.Point(13, 214);
            this.chkEBooks.Name = "chkEBooks";
            this.chkEBooks.Size = new System.Drawing.Size(230, 23);
            this.chkEBooks.TabIndex = 17;
            this.chkEBooks.Text = "Enable eBooks";
            this.chkEBooks.ToolTipText = "When enabled, the Make eBook button will show so you can start creating your own " +
    "eBooks.";
            // 
            // frmUserProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 19F);
            this.AutoScaleMode = Wisej.Web.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1079, 604);
            this.Controls.Add(this.tableLayoutPanel3);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "frmUserProfile";
            this.Text = "User Profile";
            this.Load += new System.EventHandler(this.frmProfile_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.pnlPictureBoxProfile.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProfilePic)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.TextBox txtFirstname;
        private Wisej.Web.TextBox txtPassword;
        private Wisej.Web.TextBox txtPrimaryPhone;
        private Wisej.Web.TextBox txtEmailAddress;
        private Wisej.Web.TextBox txtLastname;
        private Wisej.Web.PictureBox pictureBoxProfilePic;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel2;
        private Wisej.Web.SplitButton splitButtonMembershipUpdate;
        private Wisej.Web.MenuItem menuItem1;
        private Wisej.Web.MenuItem menuItem2;
        private Wisej.Web.MenuItem menuItem3;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel3;
        private Wisej.Web.RadioButton radioMemberTrial;
        private Wisej.Web.RadioButton radioMemberVIP;
        private Wisej.Web.RadioButton radioMemberPremium;
        private Wisej.Web.RadioButton radioMemberBasic;
        private Wisej.Web.CheckBox chkEBooks;
        private Wisej.Web.CheckBox chkAudiobooks;
        private Wisej.Web.CheckBox chkFlipbooks;
        private Wisej.Web.CheckBox chkMarketingPlans;
        private Wisej.Web.CheckBox chkBusinessPlans;
        private Wisej.Web.GroupBox groupBox1;
        private Wisej.Web.Upload uploadProfilePic;
        private Wisej.Web.Panel pnlPictureBoxProfile;
        private Wisej.Web.Button btnSaveChanges;
    }
}