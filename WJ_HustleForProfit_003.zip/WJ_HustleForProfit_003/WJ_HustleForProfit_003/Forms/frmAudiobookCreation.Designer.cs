﻿namespace WJ_HustleForProfit_003.Forms
{
    partial class frmAudiobookCreation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAudiobookCreation));
            Wisej.Web.ComponentTool componentTool1 = new Wisej.Web.ComponentTool();
            Wisej.Web.ComponentTool componentTool2 = new Wisej.Web.ComponentTool();
            Wisej.Web.ComponentTool componentTool3 = new Wisej.Web.ComponentTool();
            this.statusBarAudiobook = new Wisej.Web.StatusBar();
            this.pnlTop = new Wisej.Web.Panel();
            this.flowLayoutPanelAudiobook = new Wisej.Web.FlowLayoutPanel();
            this.line1 = new Wisej.Web.Line();
            this.splitButtonAudiobook = new Wisej.Web.SplitButton();
            this.splitButtonMenuItemNewAudiobook = new Wisej.Web.MenuItem();
            this.splitButtonMenuItemAudiobookWizard = new Wisej.Web.MenuItem();
            this.toolBarAudiobook = new Wisej.Web.ToolBar();
            this.toolBarButton1 = new Wisej.Web.ToolBarButton();
            this.pnlMain = new Wisej.Web.Panel();
            this.splitContainer1 = new Wisej.Web.SplitContainer();
            this.widget1 = new Wisej.Web.Widget();
            this.btnSaveMP3 = new Wisej.Web.Button();
            this.lvAudioChapters = new Wisej.Web.ListView();
            this.tableLayoutPanel3 = new Wisej.Web.TableLayoutPanel();
            this.txtAudiobookChapterTitle = new Wisej.Web.TextBox();
            this.lblCharCount = new Wisej.Web.Label();
            this.btnGenerateMP3 = new Wisej.Web.Button();
            this.txtAudiobookSource = new Wisej.Web.TextBox();
            this.tableLayoutPanel2 = new Wisej.Web.TableLayoutPanel();
            this.btnEBookCoverSaveAndNextStep = new Wisej.Web.Button();
            this.txtAudiobookTitle = new Wisej.Web.TextBox();
            this.txtAudiobookDescription = new Wisej.Web.TextBox();
            this.txtAudiobookAuthor = new Wisej.Web.TextBox();
            this.tableLayoutPanel1 = new Wisej.Web.TableLayoutPanel();
            this.groupBox2 = new Wisej.Web.GroupBox();
            this.label11 = new Wisej.Web.Label();
            this.uploadEBookCover = new Wisej.Web.Upload();
            this.pictureBox1 = new Wisej.Web.PictureBox();
            this.pnlTop.SuspendLayout();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // statusBarAudiobook
            // 
            this.statusBarAudiobook.Location = new System.Drawing.Point(0, 674);
            this.statusBarAudiobook.Name = "statusBarAudiobook";
            this.statusBarAudiobook.Size = new System.Drawing.Size(1334, 22);
            this.statusBarAudiobook.TabIndex = 0;
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.pnlTop.Controls.Add(this.flowLayoutPanelAudiobook);
            this.pnlTop.Controls.Add(this.line1);
            this.pnlTop.Controls.Add(this.splitButtonAudiobook);
            this.pnlTop.Dock = Wisej.Web.DockStyle.Top;
            this.pnlTop.HeaderSize = 25;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Padding = new Wisej.Web.Padding(5);
            this.pnlTop.ShowCloseButton = false;
            this.pnlTop.Size = new System.Drawing.Size(1334, 112);
            this.pnlTop.TabIndex = 3;
            // 
            // flowLayoutPanelAudiobook
            // 
            this.flowLayoutPanelAudiobook.AutoScroll = true;
            this.flowLayoutPanelAudiobook.Dock = Wisej.Web.DockStyle.Fill;
            this.flowLayoutPanelAudiobook.Location = new System.Drawing.Point(132, 5);
            this.flowLayoutPanelAudiobook.Name = "flowLayoutPanelAudiobook";
            this.flowLayoutPanelAudiobook.Padding = new Wisej.Web.Padding(0, 0, 10, 0);
            this.flowLayoutPanelAudiobook.ScrollBars = Wisej.Web.ScrollBars.Horizontal;
            this.flowLayoutPanelAudiobook.ShowCloseButton = false;
            this.flowLayoutPanelAudiobook.Size = new System.Drawing.Size(1195, 100);
            this.flowLayoutPanelAudiobook.TabIndex = 3;
            // 
            // line1
            // 
            this.line1.Dock = Wisej.Web.DockStyle.Left;
            this.line1.Location = new System.Drawing.Point(105, 5);
            this.line1.Name = "line1";
            this.line1.Orientation = Wisej.Web.Orientation.Vertical;
            this.line1.Size = new System.Drawing.Size(27, 100);
            // 
            // splitButtonAudiobook
            // 
            this.splitButtonAudiobook.Dock = Wisej.Web.DockStyle.Left;
            this.splitButtonAudiobook.Location = new System.Drawing.Point(5, 5);
            this.splitButtonAudiobook.MenuItems.AddRange(new Wisej.Web.MenuItem[] {
            this.splitButtonMenuItemNewAudiobook,
            this.splitButtonMenuItemAudiobookWizard});
            this.splitButtonAudiobook.Name = "splitButtonAudiobook";
            this.splitButtonAudiobook.Size = new System.Drawing.Size(100, 100);
            this.splitButtonAudiobook.TabIndex = 1;
            this.splitButtonAudiobook.Text = "New Audiobook Creation";
            // 
            // splitButtonMenuItemNewAudiobook
            // 
            this.splitButtonMenuItemNewAudiobook.Index = 0;
            this.splitButtonMenuItemNewAudiobook.Name = "splitButtonMenuItemNewAudiobook";
            this.splitButtonMenuItemNewAudiobook.Text = "Create New Audiobook";
            // 
            // splitButtonMenuItemAudiobookWizard
            // 
            this.splitButtonMenuItemAudiobookWizard.Index = 1;
            this.splitButtonMenuItemAudiobookWizard.Name = "splitButtonMenuItemAudiobookWizard";
            this.splitButtonMenuItemAudiobookWizard.Text = "New Audiobook Wizard";
            // 
            // toolBarAudiobook
            // 
            this.toolBarAudiobook.Buttons.AddRange(new Wisej.Web.ToolBarButton[] {
            this.toolBarButton1});
            this.toolBarAudiobook.Location = new System.Drawing.Point(0, 112);
            this.toolBarAudiobook.Name = "toolBarAudiobook";
            this.toolBarAudiobook.Size = new System.Drawing.Size(1334, 32);
            this.toolBarAudiobook.TabIndex = 4;
            this.toolBarAudiobook.TabStop = false;
            // 
            // toolBarButton1
            // 
            this.toolBarButton1.Name = "toolBarButton1";
            this.toolBarButton1.Text = "toolBarButton1";
            this.toolBarButton1.Click += new System.EventHandler(this.toolBarButton1_Click);
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.splitContainer1);
            this.pnlMain.Controls.Add(this.tableLayoutPanel3);
            this.pnlMain.Controls.Add(this.tableLayoutPanel2);
            this.pnlMain.Controls.Add(this.tableLayoutPanel1);
            this.pnlMain.Dock = Wisej.Web.DockStyle.Fill;
            this.pnlMain.Location = new System.Drawing.Point(0, 144);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.ShowCloseButton = false;
            this.pnlMain.Size = new System.Drawing.Size(1334, 530);
            this.pnlMain.TabIndex = 5;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = Wisej.Web.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(877, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = Wisej.Web.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.widget1);
            this.splitContainer1.Panel1.Controls.Add(this.btnSaveMP3);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.lvAudioChapters);
            this.splitContainer1.Size = new System.Drawing.Size(457, 530);
            this.splitContainer1.SplitterDistance = 319;
            this.splitContainer1.TabIndex = 9;
            // 
            // widget1
            // 
            this.widget1.Dock = Wisej.Web.DockStyle.Fill;
            this.widget1.InitScript = resources.GetString("widget1.InitScript");
            this.widget1.Location = new System.Drawing.Point(0, 0);
            this.widget1.Name = "widget1";
            this.widget1.Options = ((Wisej.Core.DynamicObject)(Wisej.Core.WisejSerializer.Parse("{}")));
            this.widget1.Size = new System.Drawing.Size(455, 280);
            this.widget1.TabIndex = 7;
            this.widget1.Text = "widget1";
            // 
            // btnSaveMP3
            // 
            this.btnSaveMP3.Dock = Wisej.Web.DockStyle.Bottom;
            this.btnSaveMP3.Location = new System.Drawing.Point(0, 280);
            this.btnSaveMP3.Name = "btnSaveMP3";
            this.btnSaveMP3.Size = new System.Drawing.Size(455, 37);
            this.btnSaveMP3.TabIndex = 0;
            this.btnSaveMP3.Text = "Save this Audiobook MP3";
            this.btnSaveMP3.Click += new System.EventHandler(this.btnSaveMP3_Click);
            // 
            // lvAudioChapters
            // 
            this.lvAudioChapters.AllowColumnSorting = true;
            this.lvAudioChapters.Dock = Wisej.Web.DockStyle.Fill;
            this.lvAudioChapters.Location = new System.Drawing.Point(0, 0);
            this.lvAudioChapters.Name = "lvAudioChapters";
            this.lvAudioChapters.Size = new System.Drawing.Size(457, 202);
            this.lvAudioChapters.TabIndex = 0;
            this.lvAudioChapters.View = Wisej.Web.View.Details;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.txtAudiobookChapterTitle, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.lblCharCount, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.btnGenerateMP3, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.txtAudiobookSource, 0, 1);
            this.tableLayoutPanel3.Dock = Wisej.Web.DockStyle.Left;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(576, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.Padding = new Wisej.Web.Padding(10);
            this.tableLayoutPanel3.ResizableEdges = Wisej.Web.AnchorStyles.Right;
            this.tableLayoutPanel3.RowCount = 4;
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel3.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.ShowCloseButton = false;
            this.tableLayoutPanel3.Size = new System.Drawing.Size(301, 530);
            this.tableLayoutPanel3.TabIndex = 8;
            // 
            // txtAudiobookChapterTitle
            // 
            this.txtAudiobookChapterTitle.Dock = Wisej.Web.DockStyle.Fill;
            this.txtAudiobookChapterTitle.Label.Font = new System.Drawing.Font("Arial", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.txtAudiobookChapterTitle.Label.Padding = new Wisej.Web.Padding(0, 0, 0, 1);
            this.txtAudiobookChapterTitle.LabelText = "Chapter Title";
            this.txtAudiobookChapterTitle.Location = new System.Drawing.Point(13, 13);
            this.txtAudiobookChapterTitle.Multiline = true;
            this.txtAudiobookChapterTitle.Name = "txtAudiobookChapterTitle";
            this.txtAudiobookChapterTitle.Size = new System.Drawing.Size(275, 54);
            this.txtAudiobookChapterTitle.TabIndex = 9;
            // 
            // lblCharCount
            // 
            this.lblCharCount.AutoSize = true;
            this.lblCharCount.Dock = Wisej.Web.DockStyle.Fill;
            this.lblCharCount.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblCharCount.Location = new System.Drawing.Point(13, 443);
            this.lblCharCount.Name = "lblCharCount";
            this.lblCharCount.Size = new System.Drawing.Size(275, 14);
            this.lblCharCount.TabIndex = 8;
            this.lblCharCount.Text = "Current Char Count: 0";
            this.lblCharCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnGenerateMP3
            // 
            this.btnGenerateMP3.Dock = Wisej.Web.DockStyle.Fill;
            this.btnGenerateMP3.Location = new System.Drawing.Point(13, 463);
            this.btnGenerateMP3.Name = "btnGenerateMP3";
            this.btnGenerateMP3.Size = new System.Drawing.Size(275, 54);
            this.btnGenerateMP3.TabIndex = 7;
            this.btnGenerateMP3.Text = "Save and Generate Audiobook MP3";
            this.btnGenerateMP3.Click += new System.EventHandler(this.btnGenerateMP3_Click);
            // 
            // txtAudiobookSource
            // 
            this.txtAudiobookSource.AutoSize = false;
            this.txtAudiobookSource.Dock = Wisej.Web.DockStyle.Fill;
            this.txtAudiobookSource.Label.Font = new System.Drawing.Font("Arial", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.txtAudiobookSource.Label.Padding = new Wisej.Web.Padding(0, 0, 0, 1);
            this.txtAudiobookSource.LabelText = "Chapter Text (plain text, max. 4000 chars.):";
            this.txtAudiobookSource.Location = new System.Drawing.Point(13, 73);
            this.txtAudiobookSource.Multiline = true;
            this.txtAudiobookSource.Name = "txtAudiobookSource";
            this.txtAudiobookSource.Size = new System.Drawing.Size(275, 364);
            this.txtAudiobookSource.TabIndex = 2;
            componentTool1.ImageSource = "Icons\\ado-ai-16.png";
            this.txtAudiobookSource.Tools.AddRange(new Wisej.Web.ComponentTool[] {
            componentTool1});
            this.txtAudiobookSource.ToolClick += new Wisej.Web.ToolClickEventHandler(this.txtAudiobookSource_ToolClick);
            this.txtAudiobookSource.TextChanged += new System.EventHandler(this.txtAudiobookSource_TextChanged);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.btnEBookCoverSaveAndNextStep, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.txtAudiobookTitle, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtAudiobookDescription, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.txtAudiobookAuthor, 0, 1);
            this.tableLayoutPanel2.Dock = Wisej.Web.DockStyle.Left;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(275, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.Padding = new Wisej.Web.Padding(10);
            this.tableLayoutPanel2.ResizableEdges = Wisej.Web.AnchorStyles.Right;
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 60F));
            this.tableLayoutPanel2.ShowCloseButton = false;
            this.tableLayoutPanel2.Size = new System.Drawing.Size(301, 530);
            this.tableLayoutPanel2.TabIndex = 7;
            // 
            // btnEBookCoverSaveAndNextStep
            // 
            this.btnEBookCoverSaveAndNextStep.Dock = Wisej.Web.DockStyle.Fill;
            this.btnEBookCoverSaveAndNextStep.Location = new System.Drawing.Point(13, 463);
            this.btnEBookCoverSaveAndNextStep.Name = "btnEBookCoverSaveAndNextStep";
            this.btnEBookCoverSaveAndNextStep.Size = new System.Drawing.Size(275, 54);
            this.btnEBookCoverSaveAndNextStep.TabIndex = 7;
            this.btnEBookCoverSaveAndNextStep.Text = "Save and Generate Audiobook";
            // 
            // txtAudiobookTitle
            // 
            this.txtAudiobookTitle.AutoSize = false;
            this.txtAudiobookTitle.Dock = Wisej.Web.DockStyle.Fill;
            this.txtAudiobookTitle.Label.Font = new System.Drawing.Font("Arial", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.txtAudiobookTitle.Label.Padding = new Wisej.Web.Padding(0, 0, 0, 1);
            this.txtAudiobookTitle.Label.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.txtAudiobookTitle.LabelText = "Audio Book Title:";
            this.txtAudiobookTitle.Location = new System.Drawing.Point(13, 13);
            this.txtAudiobookTitle.Multiline = true;
            this.txtAudiobookTitle.Name = "txtAudiobookTitle";
            this.txtAudiobookTitle.Size = new System.Drawing.Size(275, 54);
            this.txtAudiobookTitle.TabIndex = 0;
            componentTool2.ImageSource = "Icons\\ado-ai-16.png";
            this.txtAudiobookTitle.Tools.AddRange(new Wisej.Web.ComponentTool[] {
            componentTool2});
            this.txtAudiobookTitle.Watermark = "Audio Book Title. Put a keyword in here and click the AI icon";
            this.txtAudiobookTitle.ToolClick += new Wisej.Web.ToolClickEventHandler(this.txtAudiobookTitle_ToolClick);
            // 
            // txtAudiobookDescription
            // 
            this.txtAudiobookDescription.AutoSize = false;
            this.txtAudiobookDescription.Dock = Wisej.Web.DockStyle.Fill;
            this.txtAudiobookDescription.Label.Font = new System.Drawing.Font("Arial", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.txtAudiobookDescription.Label.Padding = new Wisej.Web.Padding(0, 0, 0, 1);
            this.txtAudiobookDescription.LabelText = "Audiobook Description:";
            this.txtAudiobookDescription.Location = new System.Drawing.Point(13, 133);
            this.txtAudiobookDescription.Multiline = true;
            this.txtAudiobookDescription.Name = "txtAudiobookDescription";
            this.txtAudiobookDescription.Padding = new Wisej.Web.Padding(0, 3, 0, 0);
            this.txtAudiobookDescription.Size = new System.Drawing.Size(275, 324);
            this.txtAudiobookDescription.TabIndex = 2;
            componentTool3.ImageSource = "Icons\\ado-ai-16.png";
            this.txtAudiobookDescription.Tools.AddRange(new Wisej.Web.ComponentTool[] {
            componentTool3});
            this.txtAudiobookDescription.ToolClick += new Wisej.Web.ToolClickEventHandler(this.txtAudiobookDescription_ToolClick);
            // 
            // txtAudiobookAuthor
            // 
            this.txtAudiobookAuthor.AutoSize = false;
            this.txtAudiobookAuthor.Label.Font = new System.Drawing.Font("Arial", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.txtAudiobookAuthor.Label.Padding = new Wisej.Web.Padding(0, 0, 0, 1);
            this.txtAudiobookAuthor.LabelText = "Author:";
            this.txtAudiobookAuthor.Location = new System.Drawing.Point(13, 73);
            this.txtAudiobookAuthor.Name = "txtAudiobookAuthor";
            this.txtAudiobookAuthor.Size = new System.Drawing.Size(275, 54);
            this.txtAudiobookAuthor.TabIndex = 2;
            this.txtAudiobookAuthor.Watermark = "Author";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.groupBox2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox1, 0, 0);
            this.tableLayoutPanel1.Dock = Wisej.Web.DockStyle.Left;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.Padding = new Wisej.Web.Padding(10);
            this.tableLayoutPanel1.ResizableEdges = Wisej.Web.AnchorStyles.Right;
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 130F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(275, 530);
            this.tableLayoutPanel1.TabIndex = 6;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.uploadEBookCover);
            this.groupBox2.Dock = Wisej.Web.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(13, 393);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(249, 124);
            this.groupBox2.TabIndex = 34;
            this.groupBox2.Text = "Upload Book Cover: ";
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(6, 44);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(239, 38);
            this.label11.TabIndex = 33;
            this.label11.Text = "Only .JPG or .PNG. Best 720x1280 or 19:6 aspect ratio. 1MB MAX!";
            // 
            // uploadEBookCover
            // 
            this.uploadEBookCover.BackColor = System.Drawing.Color.FromArgb(255, 155, 155);
            this.uploadEBookCover.Dock = Wisej.Web.DockStyle.Bottom;
            this.uploadEBookCover.Location = new System.Drawing.Point(3, 91);
            this.uploadEBookCover.Name = "uploadEBookCover";
            this.uploadEBookCover.Size = new System.Drawing.Size(243, 30);
            this.uploadEBookCover.TabIndex = 32;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = Wisej.Web.DockStyle.Fill;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(13, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Padding = new Wisej.Web.Padding(10);
            this.pictureBox1.Size = new System.Drawing.Size(249, 374);
            this.pictureBox1.SizeMode = Wisej.Web.PictureBoxSizeMode.StretchImage;
            // 
            // frmAudiobookCreation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 19F);
            this.AutoScaleMode = Wisej.Web.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1334, 696);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.toolBarAudiobook);
            this.Controls.Add(this.pnlTop);
            this.Controls.Add(this.statusBarAudiobook);
            this.Name = "frmAudiobookCreation";
            this.Text = "Audiobook Creation";
            this.Load += new System.EventHandler(this.frmAudiobookCreation_Load);
            this.pnlTop.ResumeLayout(false);
            this.pnlMain.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Wisej.Web.StatusBar statusBarAudiobook;
        private Wisej.Web.Panel pnlTop;
        private Wisej.Web.FlowLayoutPanel flowLayoutPanelAudiobook;
        private Wisej.Web.Line line1;
        private Wisej.Web.SplitButton splitButtonAudiobook;
        private Wisej.Web.MenuItem splitButtonMenuItemNewAudiobook;
        private Wisej.Web.MenuItem splitButtonMenuItemAudiobookWizard;
        private Wisej.Web.ToolBar toolBarAudiobook;
        private Wisej.Web.Panel pnlMain;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel1;
        private Wisej.Web.GroupBox groupBox2;
        private Wisej.Web.Label label11;
        private Wisej.Web.Upload uploadEBookCover;
        private Wisej.Web.PictureBox pictureBox1;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel2;
        private Wisej.Web.Button btnEBookCoverSaveAndNextStep;
        private Wisej.Web.TextBox txtAudiobookTitle;
        private Wisej.Web.TextBox txtAudiobookDescription;
        private Wisej.Web.TextBox txtAudiobookAuthor;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel3;
        private Wisej.Web.Button btnGenerateMP3;
        private Wisej.Web.TextBox txtAudiobookSource;
        private Wisej.Web.SplitContainer splitContainer1;
        private Wisej.Web.Button btnSaveMP3;
        private Wisej.Web.Widget widget1;
        private Wisej.Web.Label lblCharCount;
        private Wisej.Web.ListView lvAudioChapters;
        private Wisej.Web.TextBox txtAudiobookChapterTitle;
        private Wisej.Web.ToolBarButton toolBarButton1;
    }
}