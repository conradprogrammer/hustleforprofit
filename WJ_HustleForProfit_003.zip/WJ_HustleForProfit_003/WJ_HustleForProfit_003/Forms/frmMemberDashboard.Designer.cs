﻿namespace WJ_HustleForProfit_003.Forms
{
    partial class frmMemberDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMemberDashboard));
            this.statusBar1 = new Wisej.Web.StatusBar();
            this.pnlMainLeft = new Wisej.Web.Panel();
            this.splitContainerLeft = new Wisej.Web.SplitContainer();
            this.tableLayoutPanelButtons = new Wisej.Web.TableLayoutPanel();
            this.btnSocialMedia = new Wisej.Web.Button();
            this.btnEBooks = new Wisej.Web.Button();
            this.btnHustles = new Wisej.Web.Button();
            this.btnHome = new Wisej.Web.Button();
            this.btnProfile = new Wisej.Web.Button();
            this.tableLayoutPanelPoints = new Wisej.Web.TableLayoutPanel();
            this.label910 = new Wisej.Web.Label();
            this.label22 = new Wisej.Web.Label();
            this.label21 = new Wisej.Web.Label();
            this.label909 = new Wisej.Web.Label();
            this.label6 = new Wisej.Web.Label();
            this.label908 = new Wisej.Web.Label();
            this.label907 = new Wisej.Web.Label();
            this.label3 = new Wisej.Web.Label();
            this.lblUserEMail = new Wisej.Web.Label();
            this.label5 = new Wisej.Web.Label();
            this.pnlProfilePicture = new Wisej.Web.Panel();
            this.pictureBox1 = new Wisej.Web.PictureBox();
            this.tableLayoutPanel2 = new Wisej.Web.TableLayoutPanel();
            this.btnBuyMoreCredits = new Wisej.Web.Button();
            this.splitButton1 = new Wisej.Web.SplitButton();
            this.menuItem1 = new Wisej.Web.MenuItem();
            this.menuItem2 = new Wisej.Web.MenuItem();
            this.menuItem3 = new Wisej.Web.MenuItem();
            this.btnAudiobookCreation = new Wisej.Web.Button();
            this.pnlMainLeft.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerLeft)).BeginInit();
            this.splitContainerLeft.Panel1.SuspendLayout();
            this.splitContainerLeft.Panel2.SuspendLayout();
            this.splitContainerLeft.SuspendLayout();
            this.tableLayoutPanelButtons.SuspendLayout();
            this.tableLayoutPanelPoints.SuspendLayout();
            this.pnlProfilePicture.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusBar1
            // 
            this.statusBar1.Location = new System.Drawing.Point(0, 712);
            this.statusBar1.Name = "statusBar1";
            this.statusBar1.Size = new System.Drawing.Size(1211, 22);
            this.statusBar1.TabIndex = 0;
            this.statusBar1.Text = "Top Gigs, Hustletown, USA";
            // 
            // pnlMainLeft
            // 
            this.pnlMainLeft.Controls.Add(this.splitContainerLeft);
            this.pnlMainLeft.Dock = Wisej.Web.DockStyle.Left;
            this.pnlMainLeft.Location = new System.Drawing.Point(0, 0);
            this.pnlMainLeft.Name = "pnlMainLeft";
            this.pnlMainLeft.Padding = new Wisej.Web.Padding(10);
            this.pnlMainLeft.ShowCloseButton = false;
            this.pnlMainLeft.Size = new System.Drawing.Size(276, 712);
            this.pnlMainLeft.TabIndex = 1;
            // 
            // splitContainerLeft
            // 
            this.splitContainerLeft.Dock = Wisej.Web.DockStyle.Fill;
            this.splitContainerLeft.Location = new System.Drawing.Point(10, 10);
            this.splitContainerLeft.Name = "splitContainerLeft";
            this.splitContainerLeft.Orientation = Wisej.Web.Orientation.Horizontal;
            // 
            // splitContainerLeft.Panel1
            // 
            this.splitContainerLeft.Panel1.Controls.Add(this.tableLayoutPanelButtons);
            this.splitContainerLeft.Panel1.Controls.Add(this.tableLayoutPanelPoints);
            this.splitContainerLeft.Panel1.Controls.Add(this.pnlProfilePicture);
            this.splitContainerLeft.Panel1.Margin = new Wisej.Web.Padding(10);
            // 
            // splitContainerLeft.Panel2
            // 
            this.splitContainerLeft.Panel2.Controls.Add(this.tableLayoutPanel2);
            this.splitContainerLeft.Size = new System.Drawing.Size(256, 692);
            this.splitContainerLeft.SplitterDistance = 567;
            this.splitContainerLeft.TabIndex = 1;
            // 
            // tableLayoutPanelButtons
            // 
            this.tableLayoutPanelButtons.ColumnCount = 1;
            this.tableLayoutPanelButtons.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanelButtons.Controls.Add(this.btnAudiobookCreation, 0, 5);
            this.tableLayoutPanelButtons.Controls.Add(this.btnSocialMedia, 0, 4);
            this.tableLayoutPanelButtons.Controls.Add(this.btnEBooks, 0, 3);
            this.tableLayoutPanelButtons.Controls.Add(this.btnHustles, 0, 2);
            this.tableLayoutPanelButtons.Controls.Add(this.btnHome, 0, 0);
            this.tableLayoutPanelButtons.Controls.Add(this.btnProfile, 0, 1);
            this.tableLayoutPanelButtons.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanelButtons.Location = new System.Drawing.Point(0, 321);
            this.tableLayoutPanelButtons.Name = "tableLayoutPanelButtons";
            this.tableLayoutPanelButtons.Padding = new Wisej.Web.Padding(10);
            this.tableLayoutPanelButtons.RowCount = 9;
            this.tableLayoutPanelButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 35F));
            this.tableLayoutPanelButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 35F));
            this.tableLayoutPanelButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 35F));
            this.tableLayoutPanelButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 35F));
            this.tableLayoutPanelButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 35F));
            this.tableLayoutPanelButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 35F));
            this.tableLayoutPanelButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 35F));
            this.tableLayoutPanelButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 35F));
            this.tableLayoutPanelButtons.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 35F));
            this.tableLayoutPanelButtons.Size = new System.Drawing.Size(254, 244);
            this.tableLayoutPanelButtons.TabIndex = 0;
            // 
            // btnSocialMedia
            // 
            this.btnSocialMedia.Dock = Wisej.Web.DockStyle.Fill;
            this.btnSocialMedia.Location = new System.Drawing.Point(13, 153);
            this.btnSocialMedia.Name = "btnSocialMedia";
            this.btnSocialMedia.Size = new System.Drawing.Size(228, 29);
            this.btnSocialMedia.TabIndex = 6;
            this.btnSocialMedia.Text = "Social Marketing";
            this.btnSocialMedia.Click += new System.EventHandler(this.btnSocialMedia_Click);
            // 
            // btnEBooks
            // 
            this.btnEBooks.Dock = Wisej.Web.DockStyle.Fill;
            this.btnEBooks.Location = new System.Drawing.Point(13, 118);
            this.btnEBooks.Name = "btnEBooks";
            this.btnEBooks.Size = new System.Drawing.Size(228, 29);
            this.btnEBooks.TabIndex = 5;
            this.btnEBooks.Text = "eBook Creation";
            this.btnEBooks.Click += new System.EventHandler(this.btnEBooks_Click);
            // 
            // btnHustles
            // 
            this.btnHustles.Dock = Wisej.Web.DockStyle.Fill;
            this.btnHustles.Location = new System.Drawing.Point(13, 83);
            this.btnHustles.Name = "btnHustles";
            this.btnHustles.Size = new System.Drawing.Size(228, 29);
            this.btnHustles.TabIndex = 4;
            this.btnHustles.Text = "Hustle Listing";
            this.btnHustles.Click += new System.EventHandler(this.btnHustles_Click);
            // 
            // btnHome
            // 
            this.btnHome.Dock = Wisej.Web.DockStyle.Fill;
            this.btnHome.Location = new System.Drawing.Point(13, 13);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(228, 29);
            this.btnHome.TabIndex = 3;
            this.btnHome.Text = "Home";
            // 
            // btnProfile
            // 
            this.btnProfile.Dock = Wisej.Web.DockStyle.Fill;
            this.btnProfile.Location = new System.Drawing.Point(13, 48);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(228, 29);
            this.btnProfile.TabIndex = 0;
            this.btnProfile.Text = "User Profile";
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click);
            // 
            // tableLayoutPanelPoints
            // 
            this.tableLayoutPanelPoints.ColumnCount = 2;
            this.tableLayoutPanelPoints.ColumnStyles.Add(new Wisej.Web.ColumnStyle());
            this.tableLayoutPanelPoints.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 100F));
            this.tableLayoutPanelPoints.Controls.Add(this.label910, 1, 4);
            this.tableLayoutPanelPoints.Controls.Add(this.label22, 0, 4);
            this.tableLayoutPanelPoints.Controls.Add(this.label21, 0, 3);
            this.tableLayoutPanelPoints.Controls.Add(this.label909, 1, 3);
            this.tableLayoutPanelPoints.Controls.Add(this.label6, 0, 0);
            this.tableLayoutPanelPoints.Controls.Add(this.label908, 1, 2);
            this.tableLayoutPanelPoints.Controls.Add(this.label907, 1, 1);
            this.tableLayoutPanelPoints.Controls.Add(this.label3, 0, 1);
            this.tableLayoutPanelPoints.Controls.Add(this.lblUserEMail, 1, 0);
            this.tableLayoutPanelPoints.Controls.Add(this.label5, 0, 2);
            this.tableLayoutPanelPoints.Dock = Wisej.Web.DockStyle.Top;
            this.tableLayoutPanelPoints.Location = new System.Drawing.Point(0, 170);
            this.tableLayoutPanelPoints.Name = "tableLayoutPanelPoints";
            this.tableLayoutPanelPoints.Padding = new Wisej.Web.Padding(10);
            this.tableLayoutPanelPoints.RowCount = 7;
            this.tableLayoutPanelPoints.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 25F));
            this.tableLayoutPanelPoints.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 25F));
            this.tableLayoutPanelPoints.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 25F));
            this.tableLayoutPanelPoints.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 25F));
            this.tableLayoutPanelPoints.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 25F));
            this.tableLayoutPanelPoints.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 35F));
            this.tableLayoutPanelPoints.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanelPoints.ShowCloseButton = false;
            this.tableLayoutPanelPoints.Size = new System.Drawing.Size(254, 151);
            this.tableLayoutPanelPoints.TabIndex = 8;
            // 
            // label910
            // 
            this.label910.AutoSize = true;
            this.label910.Location = new System.Drawing.Point(102, 113);
            this.label910.Name = "label910";
            this.label910.Size = new System.Drawing.Size(24, 18);
            this.label910.TabIndex = 11;
            this.label910.Text = "0/1";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label22.Location = new System.Drawing.Point(13, 113);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(58, 15);
            this.label22.TabIndex = 10;
            this.label22.Text = "Claimed:";
            // 
            // label21
            // 
            this.label21.Anchor = ((Wisej.Web.AnchorStyles)(((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Bottom) 
            | Wisej.Web.AnchorStyles.Left)));
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label21.Location = new System.Drawing.Point(13, 88);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(78, 19);
            this.label21.TabIndex = 9;
            this.label21.Text = "Paid Credits";
            this.label21.ToolTipText = resources.GetString("label21.ToolTipText");
            // 
            // label909
            // 
            this.label909.AutoSize = true;
            this.label909.Location = new System.Drawing.Point(102, 88);
            this.label909.Name = "label909";
            this.label909.Size = new System.Drawing.Size(12, 18);
            this.label909.TabIndex = 8;
            this.label909.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label6.Location = new System.Drawing.Point(13, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 15);
            this.label6.TabIndex = 4;
            this.label6.Text = "Login:";
            // 
            // label908
            // 
            this.label908.Anchor = ((Wisej.Web.AnchorStyles)((Wisej.Web.AnchorStyles.Bottom | Wisej.Web.AnchorStyles.Left)));
            this.label908.AutoSize = true;
            this.label908.Location = new System.Drawing.Point(102, 64);
            this.label908.Name = "label908";
            this.label908.Size = new System.Drawing.Size(12, 18);
            this.label908.TabIndex = 6;
            this.label908.Text = "0";
            // 
            // label907
            // 
            this.label907.Anchor = Wisej.Web.AnchorStyles.Left;
            this.label907.AutoSize = true;
            this.label907.Location = new System.Drawing.Point(102, 38);
            this.label907.Name = "label907";
            this.label907.Size = new System.Drawing.Size(34, 18);
            this.label907.TabIndex = 5;
            this.label907.Text = "none";
            // 
            // label3
            // 
            this.label3.Anchor = Wisej.Web.AnchorStyles.Left;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label3.Location = new System.Drawing.Point(13, 40);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Membership:";
            // 
            // lblUserEMail
            // 
            this.lblUserEMail.AutoSize = true;
            this.lblUserEMail.Location = new System.Drawing.Point(102, 13);
            this.lblUserEMail.Name = "lblUserEMail";
            this.lblUserEMail.Size = new System.Drawing.Size(81, 18);
            this.lblUserEMail.TabIndex = 1;
            this.lblUserEMail.Text = "accountemail";
            // 
            // label5
            // 
            this.label5.Anchor = Wisej.Web.AnchorStyles.Left;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label5.Location = new System.Drawing.Point(13, 65);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 15);
            this.label5.TabIndex = 3;
            this.label5.Text = "Free Points:";
            this.label5.ToolTipText = "Hustle Points are matched with your Membership Credits, you also get 500 Points p" +
    "er daily login, 100 Points per video view (max 5/day) and 500 Points per email o" +
    "pen.";
            // 
            // pnlProfilePicture
            // 
            this.pnlProfilePicture.Controls.Add(this.pictureBox1);
            this.pnlProfilePicture.Dock = Wisej.Web.DockStyle.Top;
            this.pnlProfilePicture.Location = new System.Drawing.Point(0, 0);
            this.pnlProfilePicture.Name = "pnlProfilePicture";
            this.pnlProfilePicture.Padding = new Wisej.Web.Padding(10);
            this.pnlProfilePicture.Size = new System.Drawing.Size(254, 170);
            this.pnlProfilePicture.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.pictureBox1.CssStyle = "border-radius:50%";
            this.pictureBox1.ImageSource = "resource.wx/Wisej.Ext.IonicIcons/person-circle.svg";
            this.pictureBox1.Location = new System.Drawing.Point(46, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(150, 150);
            this.pictureBox1.SizeMode = Wisej.Web.PictureBoxSizeMode.StretchImage;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new Wisej.Web.ColumnStyle(Wisej.Web.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.btnBuyMoreCredits, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.splitButton1, 0, 0);
            this.tableLayoutPanel2.Dock = Wisej.Web.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.Padding = new Wisej.Web.Padding(10);
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new Wisej.Web.RowStyle(Wisej.Web.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(254, 114);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // btnBuyMoreCredits
            // 
            this.btnBuyMoreCredits.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.btnBuyMoreCredits.Dock = Wisej.Web.DockStyle.Fill;
            this.btnBuyMoreCredits.ForeColor = System.Drawing.Color.FromArgb(0, 17, 98);
            this.btnBuyMoreCredits.Location = new System.Drawing.Point(13, 63);
            this.btnBuyMoreCredits.Name = "btnBuyMoreCredits";
            this.btnBuyMoreCredits.Size = new System.Drawing.Size(228, 44);
            this.btnBuyMoreCredits.TabIndex = 10;
            this.btnBuyMoreCredits.Text = "Buy More Credits";
            // 
            // splitButton1
            // 
            this.splitButton1.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.splitButton1.Dock = Wisej.Web.DockStyle.Fill;
            this.splitButton1.Location = new System.Drawing.Point(13, 13);
            this.splitButton1.MenuItems.AddRange(new Wisej.Web.MenuItem[] {
            this.menuItem1,
            this.menuItem2,
            this.menuItem3});
            this.splitButton1.Name = "splitButton1";
            this.splitButton1.Size = new System.Drawing.Size(228, 44);
            this.splitButton1.TabIndex = 14;
            this.splitButton1.Text = "Upgrade Membership";
            // 
            // menuItem1
            // 
            this.menuItem1.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.menuItem1.Index = 0;
            this.menuItem1.Name = "menuItem1";
            this.menuItem1.SizeMode = Wisej.Web.MenuItemSizeMode.Fill;
            this.menuItem1.Text = "Basic Membership";
            // 
            // menuItem2
            // 
            this.menuItem2.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.menuItem2.Index = 1;
            this.menuItem2.Name = "menuItem2";
            this.menuItem2.SizeMode = Wisej.Web.MenuItemSizeMode.Fill;
            this.menuItem2.Text = "Premium Membership";
            // 
            // menuItem3
            // 
            this.menuItem3.BackColor = System.Drawing.Color.FromName("@table-row-background-focused");
            this.menuItem3.Index = 2;
            this.menuItem3.Name = "menuItem3";
            this.menuItem3.SizeMode = Wisej.Web.MenuItemSizeMode.Fill;
            this.menuItem3.Text = "VIP Membership";
            // 
            // btnAudiobookCreation
            // 
            this.btnAudiobookCreation.Dock = Wisej.Web.DockStyle.Fill;
            this.btnAudiobookCreation.Location = new System.Drawing.Point(13, 188);
            this.btnAudiobookCreation.Name = "btnAudiobookCreation";
            this.btnAudiobookCreation.Size = new System.Drawing.Size(228, 29);
            this.btnAudiobookCreation.TabIndex = 7;
            this.btnAudiobookCreation.Text = "Audiobook Creation";
            this.btnAudiobookCreation.Click += new System.EventHandler(this.btnAudiobookCreation_Click);
            // 
            // frmMemberDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 19F);
            this.AutoScaleMode = Wisej.Web.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromName("@Window");
            this.ClientSize = new System.Drawing.Size(1211, 734);
            this.Controls.Add(this.pnlMainLeft);
            this.Controls.Add(this.statusBar1);
            this.FormBorderStyle = Wisej.Web.FormBorderStyle.None;
            this.IsMdiContainer = true;
            this.Name = "frmMemberDashboard";
            this.Text = "Member Dashboard";
            this.WindowState = Wisej.Web.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmMemberDashboard_Load);
            this.FormClosing += new Wisej.Web.FormClosingEventHandler(this.frmMemberDashboard_FormClosing);
            this.pnlMainLeft.ResumeLayout(false);
            this.splitContainerLeft.Panel1.ResumeLayout(false);
            this.splitContainerLeft.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerLeft)).EndInit();
            this.splitContainerLeft.ResumeLayout(false);
            this.tableLayoutPanelButtons.ResumeLayout(false);
            this.tableLayoutPanelPoints.ResumeLayout(false);
            this.tableLayoutPanelPoints.PerformLayout();
            this.pnlProfilePicture.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.StatusBar statusBar1;
        private Wisej.Web.Panel pnlMainLeft;
        private Wisej.Web.SplitContainer splitContainerLeft;
        private Wisej.Web.SplitButton splitButton1;
        private Wisej.Web.MenuItem menuItem1;
        private Wisej.Web.MenuItem menuItem2;
        private Wisej.Web.MenuItem menuItem3;
        private Wisej.Web.Button btnBuyMoreCredits;
        private Wisej.Web.TableLayoutPanel tableLayoutPanelPoints;
        private Wisej.Web.Label label910;
        private Wisej.Web.Label label22;
        private Wisej.Web.Label label21;
        private Wisej.Web.Label label909;
        private Wisej.Web.Label label6;
        private Wisej.Web.Label label908;
        private Wisej.Web.Label label907;
        private Wisej.Web.Label label3;
        private Wisej.Web.Label lblUserEMail;
        private Wisej.Web.Label label5;
        private Wisej.Web.TableLayoutPanel tableLayoutPanelButtons;
        private Wisej.Web.Button btnProfile;
        private Wisej.Web.Button btnHome;
        private Wisej.Web.Button btnHustles;
        private Wisej.Web.Button btnEBooks;
        private Wisej.Web.Button btnSocialMedia;
        private Wisej.Web.TableLayoutPanel tableLayoutPanel2;
        private Wisej.Web.Panel pnlProfilePicture;
        private Wisej.Web.PictureBox pictureBox1;
        private Wisej.Web.Button btnAudiobookCreation;
    }
}