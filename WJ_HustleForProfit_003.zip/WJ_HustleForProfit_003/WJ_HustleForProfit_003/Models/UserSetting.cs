﻿namespace WJ_HustleForProfit_003.Models
{
    public class UserSetting
    {
        public int Id { get; set; }
        public string UserProfileEmail { get; set; }
        public string SettingName { get; set; }
        public string SettingValue { get; set; }
    }
}
